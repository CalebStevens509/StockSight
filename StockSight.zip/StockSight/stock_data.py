import yfinance as yf
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import time
import alpha_vantage_data

# Simple rate limiting helper
def safe_api_call(func, *args, **kwargs):
    """Helper function to make API calls with basic retry logic"""
    try:
        return func(*args, **kwargs)
    except Exception as e:
        error_message = str(e)
        if "Too Many Requests" in error_message or "Rate limited" in error_message:
            # For rate limits, we'll just return None instead of retrying
            # This prevents cascading failures during heavy usage
            return None
        raise e

def validate_ticker(ticker):
    """Validates if a ticker symbol exists using Alpha Vantage first, then yfinance"""
    # Try Alpha Vantage first
    if alpha_vantage_data.validate_ticker(ticker):
        return True
    
    # Fallback to yfinance
    try:
        ticker_obj = yf.Ticker(ticker)
        info = ticker_obj.info
        # Check if we got valid info back
        return 'regularMarketPrice' in info or 'currentPrice' in info
    except Exception as e:
        error_message = str(e)
        if "Too Many Requests" in error_message or "Rate limited" in error_message:
            print(f"Rate limit hit for {ticker}, allowing ticker anyway")
            return True
        print(f"Error validating ticker {ticker}: {e}")
        # Return True to allow adding the ticker anyway
        # We'll handle errors in the data fetching separately
        return True

def get_stock_data(ticker, period='1y'):
    """
    Fetches historical stock data for a given ticker and period
    Uses Alpha Vantage as primary source with yfinance as fallback
    
    Args:
        ticker (str): Stock ticker symbol
        period (str): Valid time periods are: '1d', '5d', '1mo', '3mo', '6mo', '1y', '2y', '5y', '10y', 'ytd', 'max'
                      Note: '1w' or '1m' are NOT valid - use '5d' or '1mo' instead
    
    Returns:
        DataFrame or None: Stock data with additional metrics or None if error occurs
    """
    # Try Alpha Vantage first
    data = alpha_vantage_data.get_stock_data(ticker, period)
    if data is not None and not data.empty:
        print(f"Successfully fetched {ticker} data from Alpha Vantage")
        return data
    
    print(f"Alpha Vantage failed for {ticker}, trying yfinance as fallback...")
    
    # Fallback to original yfinance logic
    # Validate period format - convert some common mistakes to proper format
    valid_periods = ['1d', '5d', '1mo', '3mo', '6mo', '1y', '2y', '5y', '10y', 'ytd', 'max']
    conversion_map = {
        '1w': '5d',    # 1 week → 5 days
        '1m': '1mo',   # 1 month → 1mo
        '3m': '3mo',   # 3 months → 3mo
        '6m': '6mo',   # 6 months → 6mo
    }
    
    # Convert period to valid format if needed
    if period in conversion_map:
        print(f"{ticker}: Converting period '{period}' to '{conversion_map[period]}'")
        period = conversion_map[period]
    
    # Use a safe default if period is not valid
    if period not in valid_periods:
        print(f"{ticker}: Period '{period}' is invalid, using default '1y'")
        period = '1y'
    
    try:
        # Set a reasonable timeout to avoid hanging
        ticker_obj = yf.Ticker(ticker)
        data = ticker_obj.history(period=period)
        
        # Skip if no data was returned
        if data.empty:
            print(f"No data returned for {ticker} with period {period}")
            return None
            
        # Calculate daily returns
        data['Daily_Return'] = data['Close'].pct_change()
        
        # Calculate cumulative returns
        data['Cumulative_Return'] = (1 + data['Daily_Return']).cumprod() - 1
        
        return data
    except Exception as e:
        print(f"Error fetching data for {ticker} with period {period}: {e}")
        # Try again with a safer period if this was due to an invalid period
        if "Period" in str(e) and period != '1y':
            print(f"Retrying {ticker} with default period '1y'")
            try:
                ticker_obj = yf.Ticker(ticker)
                data = ticker_obj.history(period='1y')
                
                if not data.empty:
                    # Calculate daily returns
                    data['Daily_Return'] = data['Close'].pct_change()
                    
                    # Calculate cumulative returns
                    data['Cumulative_Return'] = (1 + data['Daily_Return']).cumprod() - 1
                    
                    return data
            except Exception as inner_e:
                print(f"Second attempt failed for {ticker}: {inner_e}")
        
        return None

def get_stock_info(ticker):
    """Fetches basic information about a stock"""
    try:
        ticker_obj = yf.Ticker(ticker)
        info = ticker_obj.info
        
        # If info is None or empty, return a minimal info dict with defaults
        if not info:
            print(f"Could not fetch info for {ticker}, using minimal info.")
            return {
                'name': ticker,
                'sector': 'N/A',
                'industry': 'N/A',
                'current_price': 'N/A',
                'previous_close': 'N/A',
                'open': 'N/A',
                'day_high': 'N/A',
                'day_low': 'N/A',
                'volume': 'N/A',
                '52wk_high': 'N/A',
                '52wk_low': 'N/A',
                'market_cap': 'N/A',
                'pe_ratio': 'N/A',
                'dividend_yield': 'N/A'
            }
        
        # Extract relevant information
        stock_info = {
            'name': info.get('shortName', ticker),
            'sector': info.get('sector', 'N/A'),
            'industry': info.get('industry', 'N/A'),
            'current_price': info.get('currentPrice', info.get('regularMarketPrice', 'N/A')),
            'previous_close': info.get('previousClose', 'N/A'),
            'open': info.get('open', 'N/A'),
            'day_high': info.get('dayHigh', 'N/A'),
            'day_low': info.get('dayLow', 'N/A'),
            'volume': info.get('volume', 'N/A'),
            '52wk_high': info.get('fiftyTwoWeekHigh', 'N/A'),
            '52wk_low': info.get('fiftyTwoWeekLow', 'N/A'),
            'market_cap': info.get('marketCap', 'N/A'),
            'pe_ratio': info.get('trailingPE', 'N/A'),
            'dividend_yield': info.get('dividendYield', 'N/A') 
        }
        
        return stock_info
    except Exception as e:
        print(f"Error fetching info for {ticker}: {e}")
        # Return minimal info rather than None to prevent errors
        return {
            'name': ticker,
            'sector': 'N/A',
            'industry': 'N/A',
            'current_price': 'N/A',
            'previous_close': 'N/A',
            'open': 'N/A',
            'day_high': 'N/A',
            'day_low': 'N/A',
            'volume': 'N/A',
            '52wk_high': 'N/A',
            '52wk_low': 'N/A',
            'market_cap': 'N/A',
            'pe_ratio': 'N/A',
            'dividend_yield': 'N/A'
        }

def calculate_metrics(data):
    """Calculates performance metrics from stock data"""
    if data is None or data.empty:
        return None
    
    # Calculate various performance metrics
    latest_price = data['Close'].iloc[-1]
    
    # Daily change
    daily_change = data['Close'].pct_change().iloc[-1]
    daily_change_value = latest_price - data['Close'].iloc[-2]
    
    # Weekly change (5 trading days)
    if len(data) >= 5:
        weekly_change = (latest_price / data['Close'].iloc[-6] - 1)
        weekly_change_value = latest_price - data['Close'].iloc[-6]
    else:
        weekly_change = None
        weekly_change_value = None
    
    # Monthly change (21 trading days)
    if len(data) >= 21:
        monthly_change = (latest_price / data['Close'].iloc[-22] - 1)
        monthly_change_value = latest_price - data['Close'].iloc[-22]
    else:
        monthly_change = None
        monthly_change_value = None
    
    # Year-to-date change
    year_start = data[data.index.year == datetime.now().year].iloc[0]['Close'] if not data[data.index.year == datetime.now().year].empty else None
    if year_start is not None:
        ytd_change = (latest_price / year_start - 1)
        ytd_value = latest_price - year_start
    else:
        ytd_change = None
        ytd_value = None
    
    # Total return for entire period
    first_price = data['Close'].iloc[0]
    total_return = (latest_price / first_price - 1)
    total_return_value = latest_price - first_price
    
    # Volatility (standard deviation of daily returns)
    volatility = data['Daily_Return'].std() * np.sqrt(252)  # Annualized
    
    # Calculate annualized return
    # Use the formula: (1 + total_return)^(252/days_held) - 1
    days_held = len(data)
    if days_held > 1:
        annualized_return = (1 + total_return) ** (252 / days_held) - 1
    else:
        annualized_return = total_return  # If only one day, use total return
    
    # Calculate Sharpe ratio (using risk-free rate of 0.02 or 2%)
    risk_free_rate = 0.02
    sharpe_ratio = (annualized_return - risk_free_rate) / volatility if volatility > 0 else 0
    
    metrics = {
        'latest_price': latest_price,
        'daily_change': daily_change,
        'daily_change_value': daily_change_value,
        'weekly_change': weekly_change,
        'weekly_change_value': weekly_change_value,
        'monthly_change': monthly_change,
        'monthly_change_value': monthly_change_value,
        'ytd_change': ytd_change,
        'ytd_value': ytd_value,
        'total_return': total_return,
        'total_return_value': total_return_value,
        'volatility': volatility,
        'annualized_return': annualized_return,
        'sharpe_ratio': sharpe_ratio
    }
    
    return metrics

def get_alpha_vantage_stock_info(ticker):
    """Get improved stock information using Alpha Vantage first, then yfinance"""
    # Try Alpha Vantage first
    info = alpha_vantage_data.get_stock_info(ticker)
    if info:
        return info
    
    # Fallback to yfinance
    try:
        ticker_obj = yf.Ticker(ticker)
        yf_info = ticker_obj.info
        
        if yf_info and 'symbol' in yf_info:
            return {
                'symbol': yf_info.get('symbol', ticker),
                'name': yf_info.get('longName', yf_info.get('shortName', ticker)),
                'sector': yf_info.get('sector', 'Unknown'),
                'industry': yf_info.get('industry', 'Unknown'),
                'market_cap': yf_info.get('marketCap', 'N/A'),
                'pe_ratio': yf_info.get('trailingPE', 'N/A'),
                'dividend_yield': yf_info.get('dividendYield', 'N/A'),
                'description': yf_info.get('longBusinessSummary', '')
            }
    except Exception as e:
        print(f"Error fetching info for {ticker}: {e}")
    
    return None

def get_alpha_vantage_current_price(ticker):
    """Get current price using Alpha Vantage first, then yfinance"""
    # Try Alpha Vantage first
    price = alpha_vantage_data.get_current_price(ticker)
    if price:
        return price
    
    # Fallback to yfinance
    try:
        ticker_obj = yf.Ticker(ticker)
        data = ticker_obj.history(period="1d", interval="1m")
        if not data.empty:
            return data['Close'].iloc[-1]
    except Exception as e:
        print(f"Error fetching current price for {ticker}: {e}")
    
    return None
