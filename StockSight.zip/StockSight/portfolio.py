import pandas as pd
import numpy as np
from datetime import datetime
import stock_data
import db
import market_analysis
import fallback_recommendations

class Portfolio:
    def __init__(self):
        # Load stocks from database
        self.stocks = db.get_all_stocks()
        self.watchlist = db.get_watchlist()
        self.data = {}    # Dictionary to store stock data
        self.watchlist_data = {}  # Dictionary to store watchlist stock data
        
        # Load data for stocks if any exist
        if self.stocks:
            # Default to 1 year data, using the correct period format for yfinance
            self.update_data(period='1y')
            
        # Load data for watchlist items if any exist
        if self.watchlist:
            # Default to 1 year data, using the correct period format for yfinance
            self.update_watchlist_data(period='1y')
        
    def add_stock(self, ticker, quantity=1):
        """Add a stock to the portfolio with a specified quantity"""
        # Validate the ticker first
        if not stock_data.validate_ticker(ticker):
            return False, f"Invalid ticker: {ticker}"
        
        # Add or update the stock in our portfolio
        if ticker in self.stocks:
            self.stocks[ticker] += quantity
        else:
            self.stocks[ticker] = quantity
            
        # Save to database
        db.save_stock(ticker, self.stocks[ticker])
            
        # Fetch the stock data (using the default period '1y')
        self.data[ticker] = stock_data.get_stock_data(ticker, period='1y')
        
        return True, f"Added {quantity} shares of {ticker} to portfolio"
    
    def remove_stock(self, ticker):
        """Remove a stock from the portfolio"""
        if ticker in self.stocks:
            del self.stocks[ticker]
            if ticker in self.data:
                del self.data[ticker]
            
            # Remove from database
            db.delete_stock(ticker)
            
            return True, f"Removed {ticker} from portfolio"
        else:
            return False, f"{ticker} not found in portfolio"
    
    def update_quantity(self, ticker, quantity):
        """Update the quantity of a stock in the portfolio"""
        if ticker in self.stocks:
            if quantity <= 0:
                return self.remove_stock(ticker)
            else:
                self.stocks[ticker] = quantity
                
                # Update in database
                db.save_stock(ticker, quantity)
                
                return True, f"Updated {ticker} quantity to {quantity}"
        else:
            return False, f"{ticker} not found in portfolio"
    
    def update_data(self, period='1y'):
        """
        Update all stock data in the portfolio
        
        Args:
            period (str): Time period for data retrieval.
                        Valid values: '1d', '5d', '1mo', '3mo', '6mo', '1y', '2y', '5y', 'ytd', 'max'
        """
        for ticker in self.stocks:
            self.data[ticker] = stock_data.get_stock_data(ticker, period)
    
    def get_stock_metrics(self, ticker):
        """Get performance metrics for a specific stock"""
        if ticker not in self.data or self.data[ticker] is None:
            return None
        
        return stock_data.calculate_metrics(self.data[ticker])
    
    def get_portfolio_value(self):
        """Calculate the current total value of the portfolio"""
        total_value = 0
        for ticker, quantity in self.stocks.items():
            if ticker in self.data and self.data[ticker] is not None and not self.data[ticker].empty:
                latest_price = self.data[ticker]['Close'].iloc[-1]
                total_value += latest_price * quantity
        
        return total_value
    
    def get_portfolio_allocation(self):
        """Calculate the percentage allocation of each stock in the portfolio"""
        total_value = self.get_portfolio_value()
        if total_value == 0:
            return {}
            
        allocation = {}
        for ticker, quantity in self.stocks.items():
            if ticker in self.data and self.data[ticker] is not None and not self.data[ticker].empty:
                latest_price = self.data[ticker]['Close'].iloc[-1]
                stock_value = latest_price * quantity
                allocation[ticker] = stock_value / total_value
        
        return allocation
    
    def get_portfolio_performance(self, period='1y'):
        """Calculate the overall performance of the portfolio over time"""
        if not self.stocks:
            return None
            
        # Get the earliest common date across all stocks
        all_dates = set()
        for ticker, data in self.data.items():
            if data is not None and not data.empty:
                # Convert index to dates without timezone information
                all_dates.update(data.index.tz_localize(None).date)
        
        if not all_dates:
            return None
            
        # Create a DataFrame with dates as index
        portfolio_df = pd.DataFrame(index=sorted(all_dates))
        
        # Calculate the daily value of each stock position
        for ticker, quantity in self.stocks.items():
            if ticker in self.data and self.data[ticker] is not None and not self.data[ticker].empty:
                stock_data = self.data[ticker].copy()
                # Convert MultiIndex to single index if needed
                if isinstance(stock_data.index, pd.MultiIndex):
                    stock_data.index = stock_data.index.get_level_values(0)
                
                # Remove timezone information to avoid comparison issues
                stock_data.index = stock_data.index.tz_localize(None)
                
                stock_data['Value'] = stock_data['Close'] * quantity
                
                # Combine with portfolio DataFrame
                daily_values = stock_data['Value'].reindex(portfolio_df.index, method='ffill')
                portfolio_df[ticker] = daily_values
        
        # Calculate total portfolio value for each day
        portfolio_df['Total'] = portfolio_df.sum(axis=1)
        
        # Calculate daily returns and cumulative returns
        portfolio_df['Daily_Return'] = portfolio_df['Total'].pct_change()
        portfolio_df['Cumulative_Return'] = (1 + portfolio_df['Daily_Return']).cumprod() - 1
        
        return portfolio_df
    
    def get_portfolio_metrics(self):
        """Calculate performance metrics for the entire portfolio"""
        portfolio_df = self.get_portfolio_performance()
        
        if portfolio_df is None or portfolio_df.empty:
            return None
            
        # Calculate various metrics
        latest_value = portfolio_df['Total'].iloc[-1]
        
        # Daily change
        daily_change = portfolio_df['Daily_Return'].iloc[-1]
        daily_change_value = latest_value - portfolio_df['Total'].iloc[-2]
        
        # Weekly change (5 trading days)
        if len(portfolio_df) >= 5:
            weekly_change = (latest_value / portfolio_df['Total'].iloc[-6] - 1)
            weekly_change_value = latest_value - portfolio_df['Total'].iloc[-6]
        else:
            weekly_change = None
            weekly_change_value = None
        
        # Monthly change (21 trading days)
        if len(portfolio_df) >= 21:
            monthly_change = (latest_value / portfolio_df['Total'].iloc[-22] - 1)
            monthly_change_value = latest_value - portfolio_df['Total'].iloc[-22]
        else:
            monthly_change = None
            monthly_change_value = None
        
        # Total return for entire period
        first_value = portfolio_df['Total'].iloc[0]
        total_return = (latest_value / first_value - 1)
        total_return_value = latest_value - first_value
        
        # Volatility (standard deviation of daily returns)
        volatility = portfolio_df['Daily_Return'].std() * np.sqrt(252)  # Annualized
        
        metrics = {
            'latest_value': latest_value,
            'daily_change': daily_change,
            'daily_change_value': daily_change_value,
            'weekly_change': weekly_change,
            'weekly_change_value': weekly_change_value,
            'monthly_change': monthly_change,
            'monthly_change_value': monthly_change_value,
            'total_return': total_return,
            'total_return_value': total_return_value,
            'volatility': volatility
        }
        
        return metrics
        
    def get_stock_recommendation(self, ticker):
        """Get investment recommendation for a specific stock based on technical analysis"""
        if ticker not in self.stocks or ticker not in self.data or self.data[ticker] is None:
            return None
            
        quantity = self.stocks[ticker]
        stock_data_df = self.data[ticker]
        
        # Generate recommendation using market analysis
        recommendation = market_analysis.generate_stock_recommendation(ticker, stock_data_df, quantity)
        
        return recommendation
    
    def get_trend_analysis(self, ticker):
        """Get trend analysis for a specific stock"""
        if ticker not in self.data or self.data[ticker] is None:
            return None
            
        # Analyze trend using market analysis
        trend_data = market_analysis.identify_trend(self.data[ticker])
        
        return trend_data
    
    def get_candlestick_patterns(self, ticker):
        """Get candlestick patterns for a specific stock"""
        if ticker not in self.data or self.data[ticker] is None:
            return None
            
        # Identify candlestick patterns
        patterns = market_analysis.identify_candlestick_patterns(self.data[ticker])
        
        return patterns
    
    def get_support_resistance_levels(self, ticker):
        """Get support and resistance levels for a specific stock"""
        if ticker not in self.data or self.data[ticker] is None:
            return None
            
        # Identify support and resistance levels
        levels = market_analysis.identify_support_resistance(self.data[ticker])
        
        return levels
    
    def get_all_recommendations(self):
        """Get investment recommendations for all stocks in the portfolio"""
        if not self.stocks:
            return []
            
        recommendations = []
        failed_count = 0
        
        for ticker in self.stocks:
            recommendation = self.get_stock_recommendation(ticker)
            if recommendation:
                recommendations.append(recommendation)
            else:
                failed_count += 1
                
        # If most or all recommendations failed (likely due to API issues), 
        # fall back to sector-based recommendations
        if failed_count > len(self.stocks) * 0.5:  # More than 50% failed
            fallback_recs = fallback_recommendations.generate_fallback_recommendations(list(self.stocks.keys()))
            # Convert fallback format to our expected format
            for rec in fallback_recs:
                recommendations.append({
                    'ticker': rec['ticker'],
                    'action': rec['action'],
                    'confidence': rec['confidence'],
                    'reason': rec['reason'],
                    'analysis_type': rec['analysis_type'],
                    'quantity': self.stocks.get(rec['ticker'], 1),
                    'sector': rec.get('sector', 'Unknown'),
                    'risk_level': rec.get('risk_level', 'Unknown')
                })
                
        return recommendations
    
    def get_portfolio_insights(self):
        """Get portfolio-level insights and recommendations"""
        recommendations = self.get_all_recommendations()
        
        # Check if we're using fallback data
        using_fallback = any(rec.get('analysis_type', '').startswith('Sector-based') for rec in recommendations)
        
        if using_fallback:
            # Use fallback insights generation
            ticker_list = list(self.stocks.keys())
            fallback_recs = fallback_recommendations.generate_fallback_recommendations(ticker_list)
            insights = fallback_recommendations.generate_portfolio_insights(fallback_recs)
            insights['data_source'] = 'Sector Analysis (API Limited)'
        else:
            # Use regular analysis
            insights = self._generate_regular_insights(recommendations)
            insights['data_source'] = 'Technical Analysis'
            
        return insights
    
    def _generate_regular_insights(self, recommendations):
        """Generate insights from technical analysis recommendations"""
        if not recommendations:
            return {
                'total_positions': 0,
                'buy_signals': 0,
                'hold_signals': 0,
                'sell_signals': 0,
                'avg_confidence': 0,
                'suggestions': ["Add stocks to your portfolio to see recommendations"],
                'data_source': 'Technical Analysis'
            }
        
        buy_count = sum(1 for r in recommendations if r.get('action') == 'BUY')
        hold_count = sum(1 for r in recommendations if r.get('action') == 'HOLD')
        sell_count = sum(1 for r in recommendations if r.get('action') == 'SELL')
        
        avg_confidence = sum(r.get('confidence', 0) for r in recommendations) / len(recommendations)
        
        suggestions = []
        if buy_count > hold_count + sell_count:
            suggestions.append("Strong buying opportunities identified")
        elif sell_count > buy_count:
            suggestions.append("Consider portfolio rebalancing")
        else:
            suggestions.append("Portfolio shows balanced signals")
            
        return {
            'total_positions': len(recommendations),
            'buy_signals': buy_count,
            'hold_signals': hold_count,
            'sell_signals': sell_count,
            'avg_confidence': avg_confidence,
            'suggestions': suggestions
        }
    
    # Watchlist methods
    def add_to_watchlist(self, ticker, notes="", price_target=None):
        """Add a stock to the watchlist"""
        # Validate the ticker first
        if not stock_data.validate_ticker(ticker):
            return False, f"Invalid ticker: {ticker}"
        
        # Add to watchlist
        self.watchlist[ticker] = {"notes": notes, "price_target": price_target}
        
        # Save to database
        success, message = db.add_to_watchlist(ticker, notes, price_target)
        
        # Fetch the stock data (using the default period '1y')
        self.watchlist_data[ticker] = stock_data.get_stock_data(ticker, period='1y')
        
        return success, message
    
    def remove_from_watchlist(self, ticker):
        """Remove a stock from the watchlist"""
        if ticker in self.watchlist:
            del self.watchlist[ticker]
            if ticker in self.watchlist_data:
                del self.watchlist_data[ticker]
            
            # Remove from database
            return db.remove_from_watchlist(ticker)
        else:
            return False, f"{ticker} not found in watchlist"
    
    def update_watchlist_item(self, ticker, notes=None, price_target=None):
        """Update watchlist item information"""
        if ticker in self.watchlist:
            item_info = self.watchlist[ticker]
            
            # Update only provided values
            if notes is not None:
                item_info["notes"] = notes
            if price_target is not None:
                item_info["price_target"] = price_target
                
            self.watchlist[ticker] = item_info
            
            # Update in database
            return db.update_watchlist_item(ticker, notes, price_target)
        else:
            return False, f"{ticker} not found in watchlist"
    
    def update_watchlist_data(self, period='1y'):
        """
        Update all stock data in the watchlist
        
        Args:
            period (str): Time period for data retrieval.
                        Valid values: '1d', '5d', '1mo', '3mo', '6mo', '1y', '2y', '5y', 'ytd', 'max'
        """
        for ticker in self.watchlist:
            self.watchlist_data[ticker] = stock_data.get_stock_data(ticker, period)
    
    def get_watchlist_metrics(self, ticker):
        """Get performance metrics for a specific watchlist stock"""
        if ticker not in self.watchlist_data or self.watchlist_data[ticker] is None:
            return None
        
        return stock_data.calculate_metrics(self.watchlist_data[ticker])
    
    def get_watchlist_recommendation(self, ticker):
        """Get investment recommendation for a specific watchlist stock"""
        if ticker not in self.watchlist or ticker not in self.watchlist_data or self.watchlist_data[ticker] is None:
            return None
            
        stock_data_df = self.watchlist_data[ticker]
        
        # Generate recommendation using market analysis (quantity = 0 for watchlist items)
        recommendation = market_analysis.generate_stock_recommendation(ticker, stock_data_df, 0)
        
        return recommendation
    
    def get_all_watchlist_recommendations(self):
        """Get investment recommendations for all stocks in the watchlist"""
        if not self.watchlist:
            return []
            
        recommendations = []
        
        for ticker in self.watchlist:
            recommendation = self.get_watchlist_recommendation(ticker)
            if recommendation:
                recommendations.append(recommendation)
                
        return recommendations
    
    def get_watchlist_trend_analysis(self, ticker):
        """Get trend analysis for a specific watchlist stock"""
        if ticker not in self.watchlist_data or self.watchlist_data[ticker] is None:
            return None
            
        # Analyze trend using market analysis
        trend_data = market_analysis.identify_trend(self.watchlist_data[ticker])
        
        return trend_data
    
    def get_watchlist_patterns(self, ticker):
        """Get candlestick patterns for a specific watchlist stock"""
        if ticker not in self.watchlist_data or self.watchlist_data[ticker] is None:
            return None
            
        # Identify candlestick patterns
        patterns = market_analysis.identify_candlestick_patterns(self.watchlist_data[ticker])
        
        return patterns
    
    def get_watchlist_support_resistance(self, ticker):
        """Get support and resistance levels for a specific watchlist stock"""
        if ticker not in self.watchlist_data or self.watchlist_data[ticker] is None:
            return None
            
        # Identify support and resistance levels
        levels = market_analysis.identify_support_resistance(self.watchlist_data[ticker])
        
        return levels
