# Overview

Stock Portfolio Dashboard is a Streamlit-based web application for tracking stock investments and analyzing portfolio performance. The application provides investment recommendations based on market trends, candlestick patterns, support/resistance levels, and technical indicators. Users can manage a portfolio of stocks, maintain a watchlist, and receive data-driven investment insights using Yahoo Finance market data.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Streamlit Framework**: Single-page web application with reactive UI components
- **Plotly Visualization**: Interactive charts and graphs for stock data visualization using plotly.graph_objects and plotly.express
- **Session State Management**: Maintains portfolio and application state across user interactions

## Backend Architecture
- **Object-Oriented Design**: Core business logic encapsulated in Portfolio class
- **Modular Service Layer**: Separated concerns across multiple modules:
  - `stock_data.py`: Yahoo Finance API integration and data fetching
  - `market_analysis.py`: Technical analysis and trend identification
  - `portfolio.py`: Portfolio management and business logic
  - `fallback_recommendations.py`: Offline recommendation engine

## Data Storage
- **SQLite Database**: Local file-based storage using SQLAlchemy ORM
- **Database Models**: Two primary entities - StockModel for portfolio holdings and WatchlistModel for tracked stocks
- **Automatic Schema Management**: Database initialization and table creation handled programmatically

## Technical Analysis Engine
- **Trend Identification**: Moving average crossovers and price slope analysis
- **Risk Assessment**: Sector-based risk categorization and growth potential scoring
- **Fallback System**: Offline recommendations based on sector characteristics when API data is unavailable

## Error Handling and Resilience
- **Rate Limiting Protection**: Built-in retry logic and graceful degradation for Yahoo Finance API limits
- **Data Validation**: Ticker symbol validation with fallback acceptance
- **Offline Capability**: Fallback recommendation system for when market data is inaccessible

# External Dependencies

## Market Data Provider
- **Yahoo Finance (yfinance)**: Primary source for real-time and historical stock market data
- **Rate Limiting**: Subject to Yahoo Finance API rate limits during peak usage
- **Data Coverage**: Supports major stock exchanges and ticker symbols

## Database System
- **SQLite**: Embedded database for local data persistence
- **SQLAlchemy**: ORM layer for database operations and model management

## Visualization Libraries
- **Plotly**: Interactive charting library for financial data visualization
- **Pandas**: Data manipulation and analysis framework
- **NumPy**: Numerical computing for technical analysis calculations

## Web Framework
- **Streamlit**: Web application framework for rapid deployment and reactive UI