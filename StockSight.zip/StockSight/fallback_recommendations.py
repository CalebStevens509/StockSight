import pandas as pd
import numpy as np
from datetime import datetime

def generate_fallback_recommendations(ticker_list):
    """
    Generate investment recommendations when API data is unavailable.
    Uses general market knowledge and diversification principles.
    """
    recommendations = []
    
    # Market sectors and their characteristics
    sector_analysis = {
        'AAPL': {'sector': 'Technology', 'risk': 'Medium', 'growth_potential': 'High'},
        'MSFT': {'sector': 'Technology', 'risk': 'Medium', 'growth_potential': 'High'},
        'GOOGL': {'sector': 'Technology', 'risk': 'Medium', 'growth_potential': 'High'},
        'AMZN': {'sector': 'Consumer Discretionary', 'risk': 'Medium-High', 'growth_potential': 'High'},
        'TSLA': {'sector': 'Automotive/Energy', 'risk': 'High', 'growth_potential': 'Very High'},
        'NVDA': {'sector': 'Technology/AI', 'risk': 'High', 'growth_potential': 'Very High'},
        'META': {'sector': 'Technology', 'risk': 'Medium-High', 'growth_potential': 'High'},
        'JPM': {'sector': 'Financial', 'risk': 'Medium', 'growth_potential': 'Medium'},
        'JNJ': {'sector': 'Healthcare', 'risk': 'Low', 'growth_potential': 'Medium'},
        'PG': {'sector': 'Consumer Staples', 'risk': 'Low', 'growth_potential': 'Low-Medium'},
        'KO': {'sector': 'Consumer Staples', 'risk': 'Low', 'growth_potential': 'Low-Medium'},
        'WMT': {'sector': 'Consumer Staples', 'risk': 'Low', 'growth_potential': 'Medium'},
        'DIS': {'sector': 'Entertainment', 'risk': 'Medium', 'growth_potential': 'Medium'},
        'NFLX': {'sector': 'Entertainment', 'risk': 'Medium-High', 'growth_potential': 'High'},
        'V': {'sector': 'Financial Services', 'risk': 'Medium', 'growth_potential': 'High'},
        'MA': {'sector': 'Financial Services', 'risk': 'Medium', 'growth_potential': 'High'},
    }
    
    for ticker in ticker_list:
        ticker_upper = ticker.upper()
        
        if ticker_upper in sector_analysis:
            info = sector_analysis[ticker_upper]
            
            # Generate recommendation based on sector characteristics
            if info['risk'] == 'Low':
                if info['growth_potential'] in ['Medium', 'High']:
                    action = 'BUY'
                    reason = f"Stable {info['sector']} stock with solid fundamentals"
                else:
                    action = 'HOLD'
                    reason = f"Conservative {info['sector']} holding for income"
            elif info['risk'] == 'Medium':
                action = 'BUY'
                reason = f"Balanced risk-reward in {info['sector']} sector"
            elif info['risk'] == 'Medium-High':
                action = 'HOLD'
                reason = f"Monitor closely - {info['sector']} showing volatility"
            else:  # High risk
                if info['growth_potential'] == 'Very High':
                    action = 'HOLD'
                    reason = f"High growth potential but requires risk tolerance"
                else:
                    action = 'SELL'
                    reason = f"High risk without corresponding growth potential"
            
            confidence = 0.6  # Moderate confidence for fallback recommendations
            
        else:
            # Generic recommendation for unknown tickers
            action = 'HOLD'
            reason = "Insufficient data - maintain current position pending analysis"
            confidence = 0.4
        
        recommendations.append({
            'ticker': ticker_upper,
            'action': action,
            'confidence': confidence,
            'reason': reason,
            'analysis_type': 'Sector-based (Limited Data)',
            'sector': sector_analysis.get(ticker_upper, {}).get('sector', 'Unknown'),
            'risk_level': sector_analysis.get(ticker_upper, {}).get('risk', 'Unknown'),
            'growth_potential': sector_analysis.get(ticker_upper, {}).get('growth_potential', 'Unknown')
        })
    
    return recommendations

def generate_portfolio_insights(recommendations):
    """Generate portfolio-level insights from fallback recommendations"""
    if not recommendations:
        return {
            'total_positions': 0,
            'buy_signals': 0,
            'hold_signals': 0,
            'sell_signals': 0,
            'avg_confidence': 0,
            'dominant_sectors': [],
            'risk_distribution': {},
            'suggestions': ["Add some stocks to your portfolio to see recommendations"]
        }
    
    # Count actions
    buy_count = sum(1 for r in recommendations if r['action'] == 'BUY')
    hold_count = sum(1 for r in recommendations if r['action'] == 'HOLD')
    sell_count = sum(1 for r in recommendations if r['action'] == 'SELL')
    
    # Calculate average confidence
    avg_confidence = sum(r['confidence'] for r in recommendations) / len(recommendations)
    
    # Sector analysis
    sectors = [r['sector'] for r in recommendations if r['sector'] != 'Unknown']
    sector_counts = {}
    for sector in sectors:
        sector_counts[sector] = sector_counts.get(sector, 0) + 1
    
    dominant_sectors = sorted(sector_counts.items(), key=lambda x: x[1], reverse=True)[:3]
    
    # Risk distribution
    risks = [r['risk_level'] for r in recommendations if r['risk_level'] != 'Unknown']
    risk_counts = {}
    for risk in risks:
        risk_counts[risk] = risk_counts.get(risk, 0) + 1
    
    # Generate suggestions
    suggestions = []
    if buy_count > hold_count + sell_count:
        suggestions.append("Strong buying opportunities identified in your portfolio")
    elif sell_count > buy_count:
        suggestions.append("Consider rebalancing - multiple positions show sell signals")
    
    if len(set(sectors)) < 3:
        suggestions.append("Consider diversifying across more sectors")
    
    if risk_counts.get('High', 0) > len(recommendations) * 0.5:
        suggestions.append("Portfolio has high risk concentration - consider adding stable positions")
    
    if not suggestions:
        suggestions.append("Portfolio shows balanced risk-reward characteristics")
    
    return {
        'total_positions': len(recommendations),
        'buy_signals': buy_count,
        'hold_signals': hold_count,
        'sell_signals': sell_count,
        'avg_confidence': avg_confidence,
        'dominant_sectors': dominant_sectors,
        'risk_distribution': risk_counts,
        'suggestions': suggestions
    }