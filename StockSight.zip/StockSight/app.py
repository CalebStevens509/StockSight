import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime, timedelta
import yfinance as yf
from portfolio import Portfolio
import stock_data

# Set page configuration
st.set_page_config(
    page_title="Stock Portfolio Dashboard",
    page_icon="📈",
    layout="wide"
)

# Initialize session state
if 'portfolio' not in st.session_state:
    st.session_state.portfolio = Portfolio()

if 'time_period' not in st.session_state:
    st.session_state.time_period = '1y'

# Title and description
st.title("📈 Stock Portfolio Dashboard")
st.markdown("Track your stock investments and portfolio performance")

# Introduction to new features
st.info("""
### Investment Recommendations Dashboard
This application provides investment recommendations based on:
- **Market Trends**: Analyzing price movements to identify bullish, bearish, or sideways trends
- **Candlestick Patterns**: Detecting patterns like Doji, Hammer, Engulfing patterns, and more
- **Support & Resistance**: Identifying key price levels where stocks may reverse direction
- **Technical Indicators**: Using moving averages to confirm trends and forecast potential movements

Add stocks to your portfolio to see personalized recommendations!
""")

# Rate limiting notice
if st.session_state.get('show_rate_limit_info', True):
    with st.expander("📡 About Market Data", expanded=False):
        st.markdown("""
        **Data Source**: Yahoo Finance provides real-time market data for this application.
        
        **Rate Limiting**: If you see "Too Many Requests" messages, this means the data service is temporarily limiting requests. 
        This is normal during peak usage. Simply wait a few minutes and try again.
        
        **Best Practice**: Focus on analyzing one stock at a time for the most reliable experience.
        """)

# Sidebar - Navigation
st.sidebar.header("Navigation")

# Navigation options 
page = st.sidebar.radio("Select Page", ["Home", "Portfolio", "Watchlist", "Stock Search"])

# Time period selection - properly formatted for yfinance API
time_options = {
    '5d': '5 Days',
    '1mo': '1 Month',
    '3mo': '3 Months',
    '6mo': '6 Months',
    '1y': '1 Year',
    '2y': '2 Years',
    '5y': '5 Years',
    'ytd': 'Year to Date',
    'max': 'Maximum'
}

selected_period = st.sidebar.selectbox(
    "Select Time Period",
    options=list(time_options.keys()),
    format_func=lambda x: time_options[x],
    index=list(time_options.keys()).index('1y')
)

if selected_period != st.session_state.time_period:
    st.session_state.time_period = selected_period
    st.session_state.portfolio.update_data(period=selected_period)

# Database management section
st.sidebar.markdown("---")
st.sidebar.subheader("Database Actions")
st.sidebar.caption("Your portfolio data is automatically saved in the database.")

# Refresh data button
if st.sidebar.button("Refresh Stock Data"):
    st.session_state.portfolio.update_data(period=st.session_state.time_period)
    st.sidebar.success("Stock data refreshed successfully!")
    st.rerun()

# Add stock form
with st.sidebar.form("add_stock_form"):
    st.subheader("Add Stock to Portfolio")
    
    new_ticker = st.text_input("Stock Ticker Symbol (e.g., AAPL)").upper()
    quantity = st.number_input("Quantity", min_value=1, value=1, step=1)
    
    submit_button = st.form_submit_button("Add Stock")
    
    if submit_button and new_ticker:
        success, message = st.session_state.portfolio.add_stock(new_ticker, quantity)
        if success:
            st.sidebar.success(message)
        else:
            st.sidebar.error(message)

# Display current portfolio
st.sidebar.subheader("Your Portfolio")

if not st.session_state.portfolio.stocks:
    st.sidebar.info("Add stocks to your portfolio to get started")
else:
    # Create a form for updating quantities
    for ticker, quantity in list(st.session_state.portfolio.stocks.items()):
        col1, col2, col3 = st.sidebar.columns([2, 1, 1])
        
        with col1:
            st.write(f"{ticker}")
        
        with col2:
            new_quantity = st.number_input(
                f"Qty",
                min_value=0,
                value=int(quantity),
                step=1,
                key=f"qty_{ticker}"
            )
            
            if new_quantity != quantity:
                st.session_state.portfolio.update_quantity(ticker, new_quantity)
                st.rerun()
        
        with col3:
            if st.button("Remove", key=f"remove_{ticker}"):
                st.session_state.portfolio.remove_stock(ticker)
                st.rerun()

# Main content area
# Define common example tickers for suggestions
popular_tickers = {
    "AAPL": "Apple Inc.",
    "MSFT": "Microsoft Corporation",
    "GOOGL": "Alphabet Inc.",
    "AMZN": "Amazon.com, Inc.",
    "TSLA": "Tesla, Inc.",
    "META": "Meta Platforms, Inc.",
    "NVDA": "NVIDIA Corporation",
    "JPM": "JPMorgan Chase & Co.",
    "V": "Visa Inc.",
    "JNJ": "Johnson & Johnson"
}

# Display home, portfolio or watchlist based on selection
if page == "Home":
    # HOME PAGE
    
    # Custom CSS for modern styling
    st.markdown("""
    <style>
    .stTabs [data-baseweb="tab-list"] {
        gap: 24px;
    }
    .stTabs [data-baseweb="tab"] {
        height: 50px;
        white-space: pre-wrap;
        background-color: #f0f8ff;
        border-radius: 4px 4px 0px 0px;
        gap: 1px;
        padding-top: 10px;
        padding-bottom: 10px;
    }
    .stTabs [aria-selected="true"] {
        background-color: #3498db !important;
        color: white !important;
    }
    div.block-container {
        padding-top: 1rem;
    }
    h1, h2, h3 {
        font-weight: 600;
    }
    .recommendation-card {
        background-color: white;
        border-radius: 10px;
        padding: 20px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        margin-bottom: 20px;
        border-left: 5px solid #3498db;
    }
    .rec-buy {
        border-left: 5px solid #2ecc71 !important;
    }
    .rec-sell {
        border-left: 5px solid #e74c3c !important;
    }
    .rec-hold {
        border-left: 5px solid #f39c12 !important;
    }
    .metric-card {
        background-color: white;
        border-radius: 10px;
        padding: 1.5rem;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        margin-bottom: 10px;
        text-align: center;
    }
    .action-section {
        background-color: #f8f9fa;
        border-radius: 10px;
        padding: 15px;
        margin-bottom: 20px;
    }
    .bullish {
        color: #2ecc71;
        font-weight: bold;
    }
    .bearish {
        color: #e74c3c;
        font-weight: bold;
    }
    .neutral {
        color: #f39c12;
        font-weight: bold;
    }
    .header-banner {
        background-color: #3498db;
        padding: 20px;
        border-radius: 10px;
        color: white;
        margin-bottom: 20px;
        text-align: center;
    }
    .ticker-pill {
        background-color: #e8f4fd;
        border-radius: 20px;
        padding: 5px 12px;
        margin-right: 5px;
        color: #2980b9;
        font-weight: bold;
        display: inline-block;
        margin-bottom: 8px;
    }
    .market-card {
        background-color: white;
        border-radius: 10px;
        padding: 10px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        text-align: center;
    }
    .portfolio-summary {
        background-color: #f0f8ff;
        border-radius: 10px;
        padding: 15px;
        margin: 10px 0;
    }
    </style>
    """, unsafe_allow_html=True)
    
    # Banner with main title
    st.markdown("""
    <div class="header-banner">
        <h1>📈 Smart Stock Recommendations</h1>
        <p>Personalized investment insights and market analysis</p>
    </div>
    """, unsafe_allow_html=True)

    # Primary tabs for main sections - make recommendations the first tab
    main_tabs = st.tabs(["✨ Stock Recommendations", "📊 Portfolio Overview", "🔍 Market Analysis"])
    
    with main_tabs[0]:  # RECOMMENDATIONS TAB
        # Get recommendations based on portfolio or trending stocks
        if st.session_state.portfolio.stocks:
            all_recommendations = st.session_state.portfolio.get_all_recommendations()
            portfolio_insights = st.session_state.portfolio.get_portfolio_insights()
            
            # Show data source info
            data_source = portfolio_insights.get('data_source', 'Technical Analysis')
            if 'API Limited' in data_source:
                st.info("📊 Currently using sector-based analysis due to data service limits. Recommendations are based on fundamental sector characteristics.")
            
            if all_recommendations:
                # Group recommendations by type (handle both 'action' and 'recommendation' keys)
                buy_recs = [rec for rec in all_recommendations if rec.get('action', rec.get('recommendation', '')).upper() == 'BUY']
                sell_recs = [rec for rec in all_recommendations if rec.get('action', rec.get('recommendation', '')).upper() == 'SELL']
                hold_recs = [rec for rec in all_recommendations if rec.get('action', rec.get('recommendation', '')).upper() == 'HOLD']
                
                # Button to filter recommendations
                rec_filter = st.radio(
                    "Filter recommendations",
                    ["All", "Buy", "Sell", "Hold"],
                    horizontal=True,
                    key="rec_filter"
                )
                
                filtered_recs = all_recommendations
                if rec_filter == "Buy":
                    filtered_recs = buy_recs
                elif rec_filter == "Sell":
                    filtered_recs = sell_recs
                elif rec_filter == "Hold":
                    filtered_recs = hold_recs
                
                if filtered_recs:
                    for rec in filtered_recs:
                        # Get action from either 'action' or 'recommendation' key
                        action = rec.get('action', rec.get('recommendation', 'HOLD')).upper()
                        
                        # Set card color based on recommendation
                        card_class = "recommendation-card"
                        if action == 'BUY':
                            card_class += " rec-buy"
                        elif action == 'SELL':
                            card_class += " rec-sell"
                        elif action == 'HOLD':
                            card_class += " rec-hold"
                        
                        # Display confidence as percentage
                        confidence_pct = rec.get('confidence', 0) * 100 if rec.get('confidence', 0) <= 1 else rec.get('confidence', 0)
                        
                        st.markdown(f"""
                        <div class="{card_class}">
                            <h3>{rec['ticker']} - {action}</h3>
                            <p>Confidence: <strong>{confidence_pct:.0f}%</strong></p>
                        """, unsafe_allow_html=True)
                        
                        # Show reason/analysis
                        reason = rec.get('reason', rec.get('analysis', 'No analysis available'))
                        st.markdown(f"<p>{reason}</p>", unsafe_allow_html=True)
                        
                        # Show additional info if available
                        if 'analysis_type' in rec:
                            st.markdown(f"<small>Analysis: {rec['analysis_type']}</small>", unsafe_allow_html=True)
                        
                        if 'sector' in rec and rec['sector'] != 'Unknown':
                            st.markdown(f"<small>Sector: {rec['sector']}</small>", unsafe_allow_html=True)
                            
                        st.markdown("</div>", unsafe_allow_html=True)
                        
                        col1, col2 = st.columns([1, 2])
                        
                        with col1:
                            # Show trend with styled colors - handle missing 'trend' key
                            trend = rec.get('trend', 'neutral')
                            if trend == 'bullish':
                                st.markdown('<p class="bullish">📈 BULLISH TREND</p>', unsafe_allow_html=True)
                            elif trend == 'bearish':
                                st.markdown('<p class="bearish">📉 BEARISH TREND</p>', unsafe_allow_html=True)
                            else:
                                st.markdown('<p class="neutral">↔️ SIDEWAYS TREND</p>', unsafe_allow_html=True)
                            
                            # Display patterns if any
                            # Handle missing 'patterns' key
                            patterns = rec.get('patterns', [])
                            if patterns:
                                st.markdown("**Detected Patterns:**")
                                for pattern in patterns:
                                    signal_color = "bullish" if "bullish" in pattern['signal'] else "bearish" if "bearish" in pattern['signal'] else "neutral"
                                    st.markdown(f'<p class="{signal_color}">• {pattern["name"]}</p>', unsafe_allow_html=True)
                        
                        with col2:
                            # Display the advice
                            st.markdown("**INVESTMENT ADVICE**")
                            advice = rec.get('advice', rec.get('reason', 'No specific advice available'))
                            st.markdown(advice)
                    
                        st.markdown("</div>", unsafe_allow_html=True)
                else:
                    st.info(f"No {rec_filter.lower()} recommendations found in your portfolio")
            else:
                st.warning("Unable to generate recommendations. This may be due to API rate limits.")
                st.info("Try refreshing your stock data or add more stocks to your portfolio.")
                
                # Show trending stocks as fallback
                st.subheader("Trending Stocks to Consider")
                trending_tickers = ["AAPL", "MSFT", "TSLA", "AMZN", "NVDA"]
                
                for ticker in trending_tickers:
                    stock_info = stock_data.get_alpha_vantage_stock_info(ticker)
                    if stock_info:
                        st.markdown(f"""
                        <div class="recommendation-card">
                            <h3>{ticker} - {stock_info['name']}</h3>
                            <p>Sector: {stock_info['sector']}</p>
                        </div>
                        """, unsafe_allow_html=True)
                        
                        col1, col2 = st.columns(2)
                        with col1:
                            if st.button(f"Add {ticker} to Portfolio", key=f"trend_add_{ticker}"):
                                success, message = st.session_state.portfolio.add_stock(ticker, 1)
                                if success:
                                    st.success(message)
                                else:
                                    st.error(message)
                        with col2:
                            if st.button(f"Add {ticker} to Watchlist", key=f"trend_watch_{ticker}"):
                                st.session_state.portfolio.add_to_watchlist(ticker)
                                st.success(f"{ticker} added to watchlist")
        else:
            st.markdown("""
            <div class="action-section">
                <h3>Get Personalized Stock Recommendations</h3>
                <p>Add stocks to your portfolio to receive tailored investment advice based on technical analysis and market trends.</p>
            </div>
            """, unsafe_allow_html=True)
            
            # Quick add form for adding stocks
            with st.form("quick_add_rec", clear_on_submit=True):
                st.subheader("Add Your First Stock")
                new_ticker = st.text_input("Enter Stock Ticker Symbol (e.g., AAPL, MSFT)").upper()
                quantity = st.number_input("Quantity", min_value=1, value=1)
                
                submit = st.form_submit_button("Get Recommendations", use_container_width=True)
                
                if submit and new_ticker:
                    success, message = st.session_state.portfolio.add_stock(new_ticker, quantity)
                    if success:
                        st.success(message)
                        st.rerun()
                    else:
                        st.error(message)
            
            # Or explore popular stocks
            st.subheader("Or Explore These Popular Stocks")
            
            # Create a grid of stock cards
            cols = st.columns(3)
            popular_stock_list = list(popular_tickers.items())
            
            for i, (ticker, name) in enumerate(popular_stock_list[:6]):
                with cols[i % 3]:
                    st.markdown(f"""
                    <div class="market-card">
                        <h3>{ticker}</h3>
                        <p>{name}</p>
                    </div>
                    """, unsafe_allow_html=True)
                    
                    if st.button(f"Add {ticker}", key=f"pop_{ticker}"):
                        success, message = st.session_state.portfolio.add_stock(ticker, 1)
                        if success:
                            st.success(message)
                            st.rerun()
                        else:
                            st.error(message)

    with main_tabs[1]:  # PORTFOLIO OVERVIEW TAB
        # Portfolio summary section
        if st.session_state.portfolio.stocks:
            try:
                portfolio_metrics = st.session_state.portfolio.get_portfolio_metrics()
                
                if portfolio_metrics:
                    # Create metric cards in a grid
                    st.markdown("""
                    <div class="portfolio-summary">
                        <h3>Your Portfolio at a Glance</h3>
                    </div>
                    """, unsafe_allow_html=True)
                    
                    col1, col2, col3, col4 = st.columns(4)
                    
                    with col1:
                        st.markdown(f"""
                        <div class="metric-card">
                            <h4>Portfolio Value</h4>
                            <h2>${portfolio_metrics.get('latest_value', 0):.2f}</h2>
                            <p>{portfolio_metrics.get('daily_change'):.2%} Today</p>
                        </div>
                        """, unsafe_allow_html=True)
                    
                    with col2:
                        daily_change = portfolio_metrics.get('daily_change_value', 0)
                        color = "#2ecc71" if daily_change >= 0 else "#e74c3c"
                        
                        st.markdown(f"""
                        <div class="metric-card">
                            <h4>Daily Change</h4>
                            <h2 style="color: {color}">${abs(daily_change):.2f}</h2>
                            <p>{portfolio_metrics.get('daily_change'):.2%}</p>
                        </div>
                        """, unsafe_allow_html=True)
                    
                    with col3:
                        weekly_change = portfolio_metrics.get('weekly_change_value', 0)
                        color = "#2ecc71" if weekly_change >= 0 else "#e74c3c"
                        
                        st.markdown(f"""
                        <div class="metric-card">
                            <h4>Weekly Change</h4>
                            <h2 style="color: {color}">${abs(weekly_change):.2f}</h2>
                            <p>{portfolio_metrics.get('weekly_change'):.2%}</p>
                        </div>
                        """, unsafe_allow_html=True)
                    
                    with col4:
                        monthly_change = portfolio_metrics.get('monthly_change_value', 0)
                        color = "#2ecc71" if monthly_change >= 0 else "#e74c3c"
                        
                        st.markdown(f"""
                        <div class="metric-card">
                            <h4>Monthly Change</h4>
                            <h2 style="color: {color}">${abs(monthly_change):.2f}</h2>
                            <p>{portfolio_metrics.get('monthly_change'):.2%}</p>
                        </div>
                        """, unsafe_allow_html=True)
                    
                    # Portfolio composition
                    st.markdown("### Your Portfolio Composition")
                    
                    # Get allocation data
                    allocation = st.session_state.portfolio.get_portfolio_allocation()
                    if allocation:
                        col1, col2 = st.columns([1, 1])
                        
                        with col1:
                            # Portfolio allocation pie chart
                            fig = px.pie(
                                values=list(allocation.values()),
                                names=list(allocation.keys()),
                                title="Stock Allocation",
                                hole=0.4,
                                color_discrete_sequence=px.colors.qualitative.Bold
                            )
                            
                            fig.update_layout(
                                margin=dict(t=60, b=40, l=40, r=40)
                            )
                            
                            st.plotly_chart(fig, use_container_width=True)
                        
                        with col2:
                            # List of stocks with current values
                            st.subheader("Stock Holdings")
                            
                            for ticker, quantity in st.session_state.portfolio.stocks.items():
                                stock_data_df = st.session_state.portfolio.data.get(ticker)
                                if stock_data_df is not None and not stock_data_df.empty:
                                    latest_price = stock_data_df['Close'].iloc[-1]
                                    value = latest_price * quantity
                                    
                                    # Calculate daily change
                                    prev_price = stock_data_df['Close'].iloc[-2] if len(stock_data_df) > 1 else latest_price
                                    change_pct = (latest_price - prev_price) / prev_price
                                    
                                    color = "#2ecc71" if change_pct >= 0 else "#e74c3c"
                                    
                                    st.markdown(f"""
                                    <div style="padding: 10px; margin-bottom: 10px; border-radius: 5px; background-color: white;">
                                        <div style="display: flex; justify-content: space-between;">
                                            <div>
                                                <strong>{ticker}</strong> • {quantity} shares
                                            </div>
                                            <div>
                                                <span style="color: {color}">{change_pct:.2%}</span>
                                            </div>
                                        </div>
                                        <div style="display: flex; justify-content: space-between; margin-top: 5px;">
                                            <div>
                                                ${latest_price:.2f}
                                            </div>
                                            <div>
                                                <strong>${value:.2f}</strong>
                                            </div>
                                        </div>
                                    </div>
                                    """, unsafe_allow_html=True)
                    
                    # Portfolio performance chart
                    st.markdown("### Portfolio Performance")
                    
                    # Display portfolio performance chart
                    portfolio_performance = st.session_state.portfolio.get_portfolio_performance()
                    if portfolio_performance is not None and not portfolio_performance.empty:
                        # Create tabs for different charts
                        perf_tabs = st.tabs(["Value Over Time", "Cumulative Return"])
                        
                        with perf_tabs[0]:
                            fig = px.line(
                                portfolio_performance,
                                x=portfolio_performance.index,
                                y='Total',
                                title=f"Portfolio Value - {time_options[selected_period]}",
                                color_discrete_sequence=['#3498db'],
                            )
                            
                            fig.update_layout(
                                xaxis_title="Date",
                                yaxis_title="Value ($)",
                                hovermode="x unified",
                                showlegend=False
                            )
                            
                            st.plotly_chart(fig, use_container_width=True)
                        
                        with perf_tabs[1]:
                            fig_return = px.line(
                                portfolio_performance,
                                x=portfolio_performance.index,
                                y='Cumulative_Return',
                                title=f"Cumulative Return - {time_options[selected_period]}",
                                color_discrete_sequence=['#2ecc71']
                            )
                            
                            fig_return.update_layout(
                                xaxis_title="Date",
                                yaxis_title="Return (%)",
                                hovermode="x unified",
                                showlegend=False,
                                yaxis_tickformat='.1%'
                            )
                            
                            fig_return.update_traces(
                                hovertemplate='%{x}<br>Return: %{y:.2%}<extra></extra>'
                            )
                            
                            st.plotly_chart(fig_return, use_container_width=True)
            except Exception as e:
                st.error(f"Error loading portfolio data: {e}")
                st.info("Try refreshing the stock data from the sidebar.")
        else:
            st.markdown("""
            <div class="action-section">
                <h3>Your Portfolio is Empty</h3>
                <p>Start adding stocks to track your investments and get personalized recommendations.</p>
            </div>
            """, unsafe_allow_html=True)
            
            # Quick add form for portfolio
            with st.form("add_first_stock", clear_on_submit=True):
                st.subheader("Add Your First Stock")
                new_ticker = st.text_input("Enter Stock Ticker Symbol (e.g., AAPL, MSFT)").upper()
                quantity = st.number_input("Quantity", min_value=1, value=1)
                
                submit = st.form_submit_button("Add to Portfolio", use_container_width=True)
                
                if submit and new_ticker:
                    success, message = st.session_state.portfolio.add_stock(new_ticker, quantity)
                    if success:
                        st.success(message)
                        st.rerun()
                    else:
                        st.error(message)
            
            # Popular stocks suggestions
            st.subheader("Popular Stocks to Consider")
            stock_cols = st.columns(3)
            
            for i, (ticker, name) in enumerate(list(popular_tickers.items())[:6]):
                with stock_cols[i % 3]:
                    st.markdown(f"""
                    <div class="market-card">
                        <h3>{ticker}</h3>
                        <p>{name}</p>
                        <button key="add_{ticker}" style="background-color: #3498db; color: white; border: none; padding: 5px 10px; border-radius: 5px; cursor: pointer;">Add to Portfolio</button>
                    </div>
                    """, unsafe_allow_html=True)
                    
                    if st.button(f"Add {ticker}", key=f"portfolio_add_{ticker}"):
                        success, message = st.session_state.portfolio.add_stock(ticker, 1)
                        if success:
                            st.success(message)
                            st.rerun()
                        else:
                            st.error(message)

    with main_tabs[2]:  # MARKET ANALYSIS TAB
        # Market trends based on hot stocks or indices
        market_indices = ["^GSPC", "^DJI", "^IXIC", "^RUT"]  # S&P 500, Dow Jones, NASDAQ, Russell 2000
        index_names = {
            "^GSPC": "S&P 500", 
            "^DJI": "Dow Jones", 
            "^IXIC": "NASDAQ", 
            "^RUT": "Russell 2000"
        }
        
        st.markdown("""
        <div class="portfolio-summary">
            <h3>Market Trends & Analysis</h3>
            <p>Track major indices and market sentiment</p>
        </div>
        """, unsafe_allow_html=True)
        
        # Get market data with correct period format
        market_data = {}
        try:
            for idx in market_indices:
                # Always use a valid period format - '5d' is safe
                data = stock_data.get_stock_data(idx, period='5d')
                if data is not None and not data.empty:
                    # Calculate daily change
                    latest = data['Close'].iloc[-1]
                    prev = data['Close'].iloc[-2]
                    change = (latest - prev) / prev
                    market_data[idx] = {
                        'name': index_names.get(idx, idx),
                        'latest': latest,
                        'change': change,
                        'data': data
                    }
        except Exception as e:
            st.error(f"Error fetching market data: {e}")
        
        # Display market index cards
        if market_data:
            cols = st.columns(len(market_data))
            
            for i, (idx, data) in enumerate(market_data.items()):
                with cols[i]:
                    change_color = "#2ecc71" if data['change'] >= 0 else "#e74c3c"
                    change_icon = "📈" if data['change'] >= 0 else "📉"
                    
                    st.markdown(f"""
                    <div class="metric-card">
                        <h4>{data['name']}</h4>
                        <h2>{data['latest']:.2f}</h2>
                        <p style="color: {change_color}">{change_icon} {data['change']:.2%}</p>
                    </div>
                    """, unsafe_allow_html=True)
            
            # Display charts for major indices
            st.subheader("Major Indices Performance")
            
            # Select index to display
            selected_index = st.selectbox(
                "Select an index to view detailed chart:",
                options=list(market_data.keys()),
                format_func=lambda x: index_names.get(x, x)
            )
            
            if selected_index in market_data:
                index_data = market_data[selected_index]['data']
                
                fig = px.line(
                    index_data,
                    x=index_data.index,
                    y='Close',
                    title=f"{index_names.get(selected_index, selected_index)} - Last 5 Days",
                    color_discrete_sequence=['#3498db']
                )
                
                fig.update_layout(
                    xaxis_title="Date",
                    yaxis_title="Price",
                    hovermode="x unified",
                    showlegend=False
                )
                
                st.plotly_chart(fig, use_container_width=True)
        
        # Sector performance - static data as example
        st.subheader("Sector Performance")
        
        sectors = {
            "Technology": 2.1,
            "Healthcare": 0.8,
            "Energy": -1.2,
            "Financials": 1.5,
            "Consumer Cyclical": -0.5,
            "Communication Services": 1.3,
            "Industrials": 0.2,
            "Materials": -0.7,
            "Utilities": 0.5,
            "Real Estate": -0.9
        }
        
        # Create a bar chart for sector performance
        sector_df = pd.DataFrame({
            'Sector': list(sectors.keys()),
            'Change': list(sectors.values())
        })
        
        fig = px.bar(
            sector_df,
            x='Sector',
            y='Change',
            title="Sector Performance (%) - Past Week",
            color='Change',
            color_continuous_scale=['#e74c3c', '#f7dc6f', '#2ecc71'],
            text=sector_df['Change'].apply(lambda x: f"{x:.1f}%")
        )
        
        fig.update_layout(
            xaxis_title="",
            yaxis_title="Weekly Change (%)",
            coloraxis_showscale=False,
            margin=dict(l=20, r=20, t=40, b=0),
            yaxis_tickformat='.1%'
        )
        
        fig.update_traces(
            texttemplate='%{text}',
            textposition='outside'
        )
        
        st.plotly_chart(fig, use_container_width=True)
    
    # Quick Actions Bar at the bottom  
    st.markdown("---")
    col1, col2, col3 = st.columns(3)
    
    with col1:
        # Mini form to quickly add stocks
        with st.form("quick_add", clear_on_submit=True):
            st.subheader("Add New Stock")
            new_ticker = st.text_input("Stock Ticker Symbol").upper()
            quantity = st.number_input("Quantity", min_value=1, value=1)
            
            submit = st.form_submit_button("Add to Portfolio", use_container_width=True)
            
            if submit and new_ticker:
                success, message = st.session_state.portfolio.add_stock(new_ticker, quantity)
                if success:
                    st.success(message)
                    st.rerun()
                else:
                    st.error(message)
    
    with col2:
        # Mini form to add to watchlist
        with st.form("quick_watchlist", clear_on_submit=True):
            st.subheader("Add to Watchlist")
            watch_ticker = st.text_input("Stock Ticker Symbol").upper()
            notes = st.text_input("Notes (optional)")
            
            submit = st.form_submit_button("Add to Watchlist", use_container_width=True)
            
            if submit and watch_ticker:
                try:
                    if stock_data.validate_ticker(watch_ticker):
                        st.session_state.portfolio.add_to_watchlist(watch_ticker, notes)
                        st.success(f"{watch_ticker} added to watchlist")
                    else:
                        st.error(f"Invalid ticker symbol: {watch_ticker}")
                except Exception as e:
                    st.error(f"Error adding to watchlist: {e}")
    
    with col3:
        # Navigation shortcuts
        st.subheader("Navigation")
        
        if st.button("Go to Portfolio", use_container_width=True):
            page = "Portfolio"
            st.rerun()
        
        if st.button("Go to Watchlist", use_container_width=True):
            page = "Watchlist"
            st.rerun()
            
        if st.button("Refresh Data", use_container_width=True):
            st.session_state.portfolio.update_data(period=selected_period)
            st.session_state.portfolio.update_watchlist_data(period=selected_period)
            st.success("Stock data refreshed successfully!")
            st.rerun()
    
    # If we have portfolio stocks, use those for recommendations
    if st.session_state.portfolio.stocks:
        all_recommendations = st.session_state.portfolio.get_all_recommendations()
        if all_recommendations:
            # Filter to only show buy recommendations
            buy_recommendations = [rec for rec in all_recommendations if rec.get('action', rec.get('recommendation', 'HOLD')).upper() == 'BUY']
            
            if buy_recommendations:
                st.write("Based on your portfolio stocks, consider these opportunities:")
                
                # Create recommendation cards
                rec_cols = st.columns(min(3, len(buy_recommendations)))
                for i, rec in enumerate(buy_recommendations[:3]):  # Show max 3 recommendations
                    with rec_cols[i]:
                        st.markdown(f"### {rec['ticker']}")
                        
                        # Show trend icon - handle missing 'trend' key
                        trend = rec.get('trend', 'neutral')
                        if trend == 'bullish':
                            st.markdown("📈 **Bullish Trend**")
                        elif trend == 'bearish':
                            st.markdown("📉 **Bearish Trend**")
                        else:
                            st.markdown("↔️ **Sideways Trend**")
                        
                        st.markdown(f"**{rec['confidence']:.0%}** confidence")
                        st.write(rec['reason'][:100] + "..." if len(rec['reason']) > 100 else rec['reason'])
                        
                        # Action buttons
                        col1, col2 = st.columns(2)
                        with col1:
                            if st.button(f"Add {rec['ticker']}", key=f"add_{rec['ticker']}"):
                                success, message = st.session_state.portfolio.add_stock(rec['ticker'], 1)
                                if success:
                                    st.success(message)
                                else:
                                    st.error(message)
                        with col2:
                            if st.button(f"Watch {rec['ticker']}", key=f"watch_{rec['ticker']}"):
                                st.session_state.portfolio.add_to_watchlist(rec['ticker'])
                                st.success(f"{rec['ticker']} added to watchlist")
            else:
                st.info("No buy recommendations found for your portfolio stocks.")
                
                # If no buy recommendations, show general market trending stocks
                st.write("Consider these trending stocks in the market:")
                trending_tickers = ["AAPL", "MSFT", "TSLA", "AMZN", "NVDA"]
                
                trend_cols = st.columns(len(trending_tickers))
                for i, ticker in enumerate(trending_tickers):
                    stock_info = stock_data.get_alpha_vantage_stock_info(ticker)
                    with trend_cols[i]:
                        if stock_info:
                            st.markdown(f"### {ticker}")
                            st.caption(f"{stock_info['name']}")
                            st.markdown(f"Sector: {stock_info['sector']}")
                            
                            # Action buttons
                            col1, col2 = st.columns(2)
                            with col1:
                                if st.button(f"Add {ticker}", key=f"add_trend_{ticker}"):
                                    success, message = st.session_state.portfolio.add_stock(ticker, 1)
                                    if success:
                                        st.success(message)
                                    else:
                                        st.error(message)
                            with col2:
                                if st.button(f"Watch {ticker}", key=f"watch_trend_{ticker}"):
                                    st.session_state.portfolio.add_to_watchlist(ticker)
                                    st.success(f"{ticker} added to watchlist")
        else:
            # If API call failed for recommendations
            st.info("Unable to generate recommendations. This may be due to API rate limits.")
            st.write("Try refreshing the stock data or explore these popular stocks:")
            
            # Show example tickers
            ticker_cols = st.columns(5)
            for i, (ticker, name) in enumerate(list(popular_tickers.items())[:5]):
                with ticker_cols[i]:
                    st.markdown(f"### {ticker}")
                    st.caption(f"{name}")
                    
                    # Action buttons
                    col1, col2 = st.columns(2)
                    with col1:
                        if st.button(f"Add {ticker}", key=f"add_pop_{ticker}"):
                            success, message = st.session_state.portfolio.add_stock(ticker, 1)
                            if success:
                                st.success(message)
                            else:
                                st.error(message)
                    with col2:
                        if st.button(f"Watch {ticker}", key=f"watch_pop_{ticker}"):
                            st.session_state.portfolio.add_to_watchlist(ticker)
                            st.success(f"{ticker} added to watchlist")
    else:
        # If no portfolio stocks, show trending stocks
        st.info("Add stocks to your portfolio to get personalized recommendations.")
        st.write("In the meantime, explore these popular stocks:")
        
        # Show example tickers
        ticker_cols = st.columns(5)
        for i, (ticker, name) in enumerate(list(popular_tickers.items())[:5]):
            with ticker_cols[i]:
                st.markdown(f"### {ticker}")
                st.caption(f"{name}")
                
                # Action buttons
                col1, col2 = st.columns(2)
                with col1:
                    if st.button(f"Add {ticker}", key=f"add_ex_{ticker}"):
                        success, message = st.session_state.portfolio.add_stock(ticker, 1)
                        if success:
                            st.success(message)
                        else:
                            st.error(message)
                with col2:
                    if st.button(f"Watch {ticker}", key=f"watch_ex_{ticker}"):
                        st.session_state.portfolio.add_to_watchlist(ticker)
                        st.success(f"{ticker} added to watchlist")
    
    # Portfolio advice section
    if st.session_state.portfolio.stocks:
        st.markdown("---")
        st.header("Portfolio Insights")
        
        # Get portfolio allocation for diversification advice
        try:
            allocation = st.session_state.portfolio.get_portfolio_allocation()
            if allocation:
                # Create two columns
                col1, col2 = st.columns([1, 2])
                
                with col1:
                    # Show a small allocation chart
                    fig = px.pie(
                        values=list(allocation.values()),
                        names=list(allocation.keys()),
                        title="Portfolio Allocation",
                        hole=0.4
                    )
                    
                    fig.update_layout(
                        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
                        margin=dict(l=20, r=20, t=40, b=20),
                        height=300
                    )
                    
                    st.plotly_chart(fig, use_container_width=True)
                
                with col2:
                    st.subheader("Diversification Analysis")
                    
                    # Analysis of allocation
                    max_allocation = max(allocation.values())
                    max_ticker = max(allocation.items(), key=lambda x: x[1])[0]
                    
                    if max_allocation > 0.5:
                        st.warning(f"⚠️ Your portfolio is heavily concentrated in {max_ticker} ({max_allocation:.1%})")
                        st.markdown("""
                        **Recommendation:** Consider diversifying your investments across more sectors
                        to reduce overall portfolio risk.
                        """)
                    elif max_allocation > 0.3:
                        st.info(f"ℹ️ {max_ticker} represents {max_allocation:.1%} of your portfolio")
                        st.markdown("""
                        **Recommendation:** Your portfolio has moderate concentration. Consider adding
                        stocks from different sectors for better diversification.
                        """)
                    else:
                        st.success("✅ Your portfolio appears to be well-diversified")
                        st.markdown("""
                        **Recommendation:** Continue maintaining a diversified approach to
                        help minimize risk across different market conditions.
                        """)
                    
                    # Get sector information if available
                    sectors = {}
                    for ticker in st.session_state.portfolio.stocks:
                        stock_info = stock_data.get_alpha_vantage_stock_info(ticker)
                        if stock_info and 'sector' in stock_info:
                            sector = stock_info['sector']
                            if sector in sectors:
                                sectors[sector] += 1
                            else:
                                sectors[sector] = 1
                    
                    if sectors:
                        sector_count = len(sectors)
                        if sector_count == 1:
                            st.warning("⚠️ All your stocks are from the same sector")
                        elif sector_count <= 3:
                            st.info(f"ℹ️ Your portfolio spans {sector_count} different sectors")
                        else:
                            st.success(f"✅ Your portfolio is diversified across {sector_count} sectors")
        except Exception as e:
            st.error(f"Error analyzing portfolio: {e}")
            st.info("Try refreshing the stock data using the button in the sidebar.")

elif page == "Portfolio":
    # PORTFOLIO PAGE
    if not st.session_state.portfolio.stocks:
        st.info("Please add stocks to your portfolio using the sidebar")
        
        # Show example tickers
        st.markdown("### Popular Stock Tickers:")
        
        ticker_cols = st.columns(2)
        for i, (ticker, name) in enumerate(popular_tickers.items()):
            with ticker_cols[i % 2]:
                st.write(f"**{ticker}**: {name}")
    else:
        # Investment Strategy & Insights Section - NEW SECTION
        st.markdown("""
        <div style="background-color:#f6f6f6; padding:20px; border-radius:10px; margin-bottom:30px;">
            <h2 style="text-align:center; margin-bottom:20px;">Investment Strategy & Market Insights</h2>
        </div>
        """, unsafe_allow_html=True)
        
        # Get all portfolio recommendations
        recommendations = st.session_state.portfolio.get_all_recommendations()
        
        if recommendations:
            # Count recommendation types
            buy_count = sum(1 for rec in recommendations if rec.get('action', rec.get('recommendation', '')).upper() == 'BUY')
            sell_count = sum(1 for rec in recommendations if rec.get('action', rec.get('recommendation', '')).upper() == 'SELL')
            hold_count = sum(1 for rec in recommendations if rec.get('action', rec.get('recommendation', '')).upper() == 'HOLD')
            total_count = len(recommendations)
            
            # Calculate percentages
            buy_pct = buy_count / total_count if total_count > 0 else 0
            sell_pct = sell_count / total_count if total_count > 0 else 0
            hold_pct = hold_count / total_count if total_count > 0 else 0
            
            # Display portfolio sentiment indicator
            col1, col2 = st.columns([1, 2])
            
            with col1:
                # Portfolio action gauge (visualization)
                fig = go.Figure(go.Indicator(
                    mode = "gauge+number",
                    value = buy_count - sell_count,
                    title = {'text': "Portfolio Action Gauge"},
                    gauge = {
                        'axis': {'range': [-total_count, total_count], 'tickwidth': 1},
                        'bar': {'color': "rgba(0,0,0,0)"},
                        'steps': [
                            {'range': [-total_count, -1], 'color': "rgba(231, 76, 60, 0.7)"},
                            {'range': [-1, 1], 'color': "rgba(241, 196, 15, 0.7)"},
                            {'range': [1, total_count], 'color': "rgba(46, 204, 113, 0.7)"}
                        ],
                        'threshold': {
                            'line': {'color': "red", 'width': 4},
                            'thickness': 0.75,
                            'value': 0
                        }
                    }
                ))
                
                fig.update_layout(
                    height=250,
                    margin=dict(l=30, r=30, t=50, b=30),
                )
                
                st.plotly_chart(fig, use_container_width=True)
                
                # Action distribution
                st.markdown("### Action Distribution")
                
                # Create action distribution pie chart
                fig = px.pie(
                    values=[buy_count, hold_count, sell_count],
                    names=["Buy", "Hold", "Sell"],
                    color_discrete_sequence=["#2ecc71", "#f39c12", "#e74c3c"],
                    hole=0.4
                )
                
                fig.update_layout(
                    margin=dict(l=10, r=10, t=10, b=10),
                    height=200,
                    showlegend=True,
                    legend=dict(orientation="h", yanchor="bottom", y=-0.3, xanchor="center", x=0.5)
                )
                
                st.plotly_chart(fig, use_container_width=True)
            
            with col2:
                # Overall portfolio assessment
                if buy_count > sell_count and buy_pct > 0.5:
                    market_sentiment = "Strongly Bullish"
                    sentiment_color = "#27ae60"
                    emoji = "📈"
                elif buy_count > sell_count:
                    market_sentiment = "Moderately Bullish"
                    sentiment_color = "#2ecc71"
                    emoji = "📈"
                elif sell_count > buy_count and sell_pct > 0.5:
                    market_sentiment = "Strongly Bearish"
                    sentiment_color = "#c0392b"
                    emoji = "📉"
                elif sell_count > buy_count:
                    market_sentiment = "Moderately Bearish"
                    sentiment_color = "#e74c3c"
                    emoji = "📉"
                else:
                    market_sentiment = "Neutral"
                    sentiment_color = "#f39c12"
                    emoji = "↔️"
                
                st.markdown(f"""
                <h3>Portfolio Market Sentiment: <span style="color:{sentiment_color}">{emoji} {market_sentiment}</span></h3>
                
                <div style="background-color:white; padding:15px; border-radius:5px; margin-top:15px;">
                    <h4>Quantitative Analysis Summary</h4>
                    <ul>
                        <li><strong>{buy_count}</strong> stocks showing buy signals ({buy_pct:.0%})</li>
                        <li><strong>{hold_count}</strong> stocks suggesting hold position ({hold_pct:.0%})</li>
                        <li><strong>{sell_count}</strong> stocks with sell indicators ({sell_pct:.0%})</li>
                    </ul>
                </div>
                """, unsafe_allow_html=True)
                
                # Market trend summary from portfolio stocks
                bullish_trends = sum(1 for rec in recommendations if rec.get('trend', 'neutral') == 'bullish')
                bearish_trends = sum(1 for rec in recommendations if rec.get('trend', 'neutral') == 'bearish')
                
                # Generate market outlook based on trends
                if bullish_trends > bearish_trends:
                    trend_direction = "upward"
                    trend_advice = "Consider increasing positions in growth stocks"
                    trend_color = "#27ae60"
                elif bearish_trends > bullish_trends:
                    trend_direction = "downward"
                    trend_advice = "Consider defensive positions and reducing risk exposure"
                    trend_color = "#e74c3c"
                else:
                    trend_direction = "sideways"
                    trend_advice = "Maintain balanced positions with selective opportunities"
                    trend_color = "#f39c12"
                
                # Market conditions assessment
                st.markdown(f"""
                <div style="background-color:white; padding:15px; border-radius:5px; margin-top:15px;">
                    <h4>Market Conditions Analysis</h4>
                    <p>Current market trends for your portfolio stocks are predominantly <span style="color:{trend_color}; font-weight:bold;">{trend_direction}</span>.</p>
                    <p><strong>Strategic Recommendation:</strong> {trend_advice}.</p>
                </div>
                """, unsafe_allow_html=True)
                
                # Actionable advice based on portfolio composition
                st.markdown("""
                <div style="background-color:white; padding:15px; border-radius:5px; margin-top:15px;">
                    <h4>Investment Strategy Recommendations</h4>
                """, unsafe_allow_html=True)
                
                # Top action recommendations
                top_buys = [rec for rec in recommendations if rec.get('action', rec.get('recommendation', 'HOLD')).upper() == 'BUY']
                top_sells = [rec for rec in recommendations if rec.get('action', rec.get('recommendation', 'HOLD')).upper() == 'SELL']
                
                # Sort by confidence
                top_buys = sorted(top_buys, key=lambda x: x['confidence'], reverse=True)[:3]
                top_sells = sorted(top_sells, key=lambda x: x['confidence'], reverse=True)[:3]
                
                if top_buys:
                    buy_tickers = ", ".join([f"<strong>{rec['ticker']}</strong> ({rec['confidence']:.0%})" for rec in top_buys])
                    st.markdown(f"<p>🔍 <strong>Consider increasing positions in:</strong> {buy_tickers}</p>", unsafe_allow_html=True)
                
                if top_sells:
                    sell_tickers = ", ".join([f"<strong>{rec['ticker']}</strong> ({rec['confidence']:.0%})" for rec in top_sells])
                    st.markdown(f"<p>⚠️ <strong>Consider reducing exposure to:</strong> {sell_tickers}</p>", unsafe_allow_html=True)
                
                st.markdown("</div>", unsafe_allow_html=True)
                
            # Detailed advice section with tabbed recommendations
            st.markdown("### Detailed Stock Analysis & Recommendations")
            
            # Create tabs for Buy, Sell, Hold recommendations
            advice_tabs = st.tabs(["Buy Recommendations", "Sell Recommendations", "Hold Recommendations"])
            
            with advice_tabs[0]:  # Buy recommendations
                buy_recs = [rec for rec in recommendations if rec.get('action', rec.get('recommendation', 'HOLD')).upper() == 'BUY']
                if buy_recs:
                    for rec in buy_recs:
                        with st.expander(f"{rec['ticker']} - {rec.get('confidence', 0):.0%} Confidence"):
                            col1, col2 = st.columns([1, 2])
                            
                            with col1:
                                # Show trend icon
                                trend = rec.get('trend', 'neutral')
                                if trend == 'bullish':
                                    st.markdown("### 📈 Bullish Trend")
                                elif trend == 'bearish':
                                    st.markdown("### 📉 Bearish Trend")
                                else:
                                    st.markdown("### ↔️ Sideways Trend")
                                    
                                # Display patterns if any
                                patterns = rec.get('patterns', [])
                                if patterns:
                                    st.markdown("#### Technical Patterns:")
                                    for pattern in patterns:
                                        signal_color = "green" if "bullish" in pattern.get('signal', '') else "red" if "bearish" in pattern.get('signal', '') else "gray"
                                        st.markdown(f"- <span style='color:{signal_color}'>{pattern.get('name', 'Unknown')}</span>", unsafe_allow_html=True)
                                        
                                # Add quantitative metrics
                                if 'metrics' in rec:
                                    st.markdown("#### Key Metrics:")
                                    metrics = rec['metrics']
                                    
                                    # Display momentum score if available
                                    if 'momentum' in metrics:
                                        momentum = metrics['momentum']
                                        st.progress(min(1.0, max(0.0, momentum/100)), text=f"Momentum: {momentum:.0f}/100")
                                    
                                    # Display risk score if available
                                    if 'risk' in metrics:
                                        risk = metrics['risk']
                                        st.progress(min(1.0, max(0.0, risk/100)), text=f"Risk Level: {risk:.0f}/100")
                            
                            with col2:
                                # Display the recommendation reasoning
                                st.markdown("### Investment Analysis")
                                st.markdown(rec.get('reason', 'No analysis available'))
                                
                                st.markdown("### Actionable Advice")
                                st.markdown(rec.get('advice', 'No specific advice available'))
                                
                                # Add quantitative targets if available
                                if 'targets' in rec:
                                    targets = rec['targets']
                                    st.markdown("### Price Targets")
                                    
                                    col1, col2 = st.columns(2)
                                    with col1:
                                        if 'resistance' in targets:
                                            st.metric("Resistance", f"${targets['resistance']:.2f}")
                                    with col2:
                                        if 'support' in targets:
                                            st.metric("Support", f"${targets['support']:.2f}")
                                
                                # Show potential return calculations
                                if 'potential_return' in rec:
                                    pot_return = rec['potential_return']
                                    st.metric("Potential Return", f"{pot_return:.1%}")
                else:
                    st.info("No buy recommendations for your portfolio stocks at this time.")
            
            with advice_tabs[1]:  # Sell recommendations
                sell_recs = [rec for rec in recommendations if rec.get('action', rec.get('recommendation', 'HOLD')).upper() == 'SELL']
                if sell_recs:
                    for rec in sell_recs:
                        with st.expander(f"{rec['ticker']} - {rec.get('confidence', 0):.0%} Confidence"):
                            col1, col2 = st.columns([1, 2])
                            
                            with col1:
                                # Show trend icon
                                trend = rec.get('trend', 'neutral')
                                if trend == 'bullish':
                                    st.markdown("### 📈 Bullish Trend")
                                elif trend == 'bearish':
                                    st.markdown("### 📉 Bearish Trend")
                                else:
                                    st.markdown("### ↔️ Sideways Trend")
                                    
                                # Display patterns if any
                                patterns = rec.get('patterns', [])
                                if patterns:
                                    st.markdown("#### Technical Patterns:")
                                    for pattern in patterns:
                                        signal_color = "green" if "bullish" in pattern.get('signal', '') else "red" if "bearish" in pattern.get('signal', '') else "gray"
                                        st.markdown(f"- <span style='color:{signal_color}'>{pattern.get('name', 'Unknown')}</span>", unsafe_allow_html=True)
                                        
                                # Add risk indicators
                                st.markdown("#### Risk Indicators:")
                                if 'risk_factors' in rec:
                                    for factor in rec.get('risk_factors', []):
                                        st.markdown(f"- {factor}")
                            
                            with col2:
                                # Display the recommendation reasoning
                                st.markdown("### Investment Analysis")
                                st.markdown(rec.get('reason', 'No analysis available'))
                                
                                st.markdown("### Actionable Advice")
                                st.markdown(rec.get('advice', 'No specific advice available'))
                                
                                # Add exit strategy if available
                                if 'exit_strategy' in rec:
                                    st.markdown("### Suggested Exit Strategy")
                                    st.markdown(rec['exit_strategy'])
                else:
                    st.info("No sell recommendations for your portfolio stocks at this time.")
            
            with advice_tabs[2]:  # Hold recommendations
                hold_recs = [rec for rec in recommendations if rec.get('action', rec.get('recommendation', 'HOLD')).upper() == 'HOLD']
                if hold_recs:
                    for rec in hold_recs:
                        with st.expander(f"{rec['ticker']} - {rec.get('confidence', 0):.0%} Confidence"):
                            col1, col2 = st.columns([1, 2])
                            
                            with col1:
                                # Show trend icon
                                trend = rec.get('trend', 'neutral')
                                if trend == 'bullish':
                                    st.markdown("### 📈 Bullish Trend")
                                elif trend == 'bearish':
                                    st.markdown("### 📉 Bearish Trend")
                                else:
                                    st.markdown("### ↔️ Sideways Trend")
                                    
                                # Display patterns if any
                                patterns = rec.get('patterns', [])
                                if patterns:
                                    st.markdown("#### Technical Patterns:")
                                    for pattern in patterns:
                                        signal_color = "green" if "bullish" in pattern.get('signal', '') else "red" if "bearish" in pattern.get('signal', '') else "gray"
                                        st.markdown(f"- <span style='color:{signal_color}'>{pattern.get('name', 'Unknown')}</span>", unsafe_allow_html=True)
                                
                                # Add position strength indicator
                                if 'position_strength' in rec:
                                    st.markdown("#### Position Strength:")
                                    strength = rec['position_strength']
                                    st.progress(min(1.0, max(0.0, strength/100)), text=f"Strength: {strength:.0f}/100")
                            
                            with col2:
                                # Display the recommendation reasoning
                                st.markdown("### Investment Analysis")
                                st.markdown(rec.get('reason', 'No analysis available'))
                                
                                st.markdown("### Monitoring Guidance")
                                st.markdown(rec.get('advice', 'No specific advice available'))
                                
                                # Add price watch levels if available
                                if 'watch_levels' in rec:
                                    levels = rec['watch_levels']
                                    st.markdown("### Price Watch Levels")
                                    
                                    col1, col2, col3 = st.columns(3)
                                    with col1:
                                        if 'buy_below' in levels:
                                            st.metric("Buy Below", f"${levels['buy_below']:.2f}")
                                    with col2:
                                        if 'current' in levels:
                                            st.metric("Current", f"${levels['current']:.2f}")
                                    with col3:
                                        if 'sell_above' in levels:
                                            st.metric("Sell Above", f"${levels['sell_above']:.2f}")
                else:
                    st.info("No hold recommendations for your portfolio stocks at this time.")
        else:
            st.info("Unable to generate investment recommendations. This may be due to insufficient data or API rate limits.")
            st.write("Try refreshing the stock data using the button in the sidebar.")
        
        # Traditional Portfolio Overview Section
        st.markdown("""
        <div style="background-color:#f6f6f6; padding:20px; border-radius:10px; margin-bottom:30px; margin-top:40px;">
            <h2 style="text-align:center; margin-bottom:20px;">Portfolio Performance Overview</h2>
        </div>
        """, unsafe_allow_html=True)
        st.header("Portfolio Overview")
    
        # Get portfolio metrics
        try:
            portfolio_metrics = st.session_state.portfolio.get_portfolio_metrics()
            
            if portfolio_metrics:
                col1, col2, col3, col4 = st.columns(4)
                
                with col1:
                    st.metric(
                        "Portfolio Value", 
                        f"${portfolio_metrics.get('latest_value', 0):.2f}", 
                        f"{portfolio_metrics.get('daily_change'):.2%}" if portfolio_metrics.get('daily_change') is not None else None
                    )
                
                with col2:
                    st.metric(
                        "Daily Change", 
                        f"${portfolio_metrics.get('daily_change_value', 0):.2f}" if portfolio_metrics.get('daily_change_value') is not None else "N/A", 
                        f"{portfolio_metrics.get('daily_change'):.2%}" if portfolio_metrics.get('daily_change') is not None else None
                    )
                    
                with col3:
                    st.metric(
                        "Weekly Change", 
                        f"${portfolio_metrics.get('weekly_change_value', 0):.2f}" if portfolio_metrics.get('weekly_change_value') is not None else "N/A",
                        f"{portfolio_metrics.get('weekly_change'):.2%}" if portfolio_metrics.get('weekly_change') is not None else None
                    )
                    
                with col4:
                    st.metric(
                        "Monthly Change", 
                        f"${portfolio_metrics.get('monthly_change_value', 0):.2f}" if portfolio_metrics.get('monthly_change_value') is not None else "N/A",
                        f"{portfolio_metrics.get('monthly_change'):.2%}" if portfolio_metrics.get('monthly_change') is not None else None
                    )
            else:
                st.warning("Could not calculate portfolio metrics. This may be due to Yahoo Finance API rate limits or connection issues. Try refreshing the stock data.")
                # Show empty placeholders
                col1, col2, col3, col4 = st.columns(4)
                with col1:
                    st.metric("Portfolio Value", "N/A")
                with col2:
                    st.metric("Daily Change", "N/A")
                with col3:
                    st.metric("Weekly Change", "N/A")
                with col4:
                    st.metric("Monthly Change", "N/A")
        except Exception as e:
            st.error(f"Error calculating portfolio metrics: {e}")
            # Show empty placeholders
            col1, col2, col3, col4 = st.columns(4)
            with col1:
                st.metric("Portfolio Value", "N/A")
            with col2:
                st.metric("Daily Change", "N/A")
            with col3:
                st.metric("Weekly Change", "N/A")
            with col4:
                st.metric("Monthly Change", "N/A")
        
        # Portfolio Performance Chart
        st.subheader("Portfolio Performance")
        
        try:
            portfolio_performance = st.session_state.portfolio.get_portfolio_performance()
            
            if portfolio_performance is not None and not portfolio_performance.empty:
                # Create a line chart for portfolio performance
                fig = px.line(
                    portfolio_performance, 
                    x=portfolio_performance.index, 
                    y='Total',
                    title=f"Portfolio Value Over Time ({time_options[selected_period]})"
                )
                
                fig.update_layout(
                    xaxis_title="Date",
                    yaxis_title="Value ($)",
                    hovermode="x unified",
                    legend_title="Portfolio"
                )
                
                st.plotly_chart(fig, use_container_width=True)
                
                # Portfolio Return Chart
                fig_return = px.line(
                    portfolio_performance, 
                    x=portfolio_performance.index, 
                    y='Cumulative_Return',
                    title=f"Portfolio Cumulative Return ({time_options[selected_period]})"
                )
                
                fig_return.update_layout(
                    xaxis_title="Date",
                    yaxis_title="Return (%)",
                    hovermode="x unified"
                )
                
                # Update y-axis format to percentage
                fig_return.update_traces(
                    hovertemplate='%{x}<br>Return: %{y:.2%}<extra></extra>'
                )
                fig_return.update_layout(yaxis_tickformat='.1%')
                
                st.plotly_chart(fig_return, use_container_width=True)
            else:
                st.info("Could not generate portfolio performance charts. This may be due to Yahoo Finance API rate limits or connection issues.")
                st.write("Try refreshing the stock data using the button in the sidebar.")
        except Exception as e:
            st.error(f"Error generating portfolio performance charts: {e}")
            st.info("Try refreshing the stock data using the button in the sidebar.")
        
        # Portfolio Allocation
        st.subheader("Portfolio Allocation")
        
        try:
            allocation = st.session_state.portfolio.get_portfolio_allocation()
            
            if allocation:
                # Create a pie chart for portfolio allocation
                fig = px.pie(
                    values=list(allocation.values()),
                    names=list(allocation.keys()),
                    title="Current Portfolio Allocation",
                    hole=0.4
                )
                
                fig.update_traces(
                    textposition='inside',
                    textinfo='percent+label',
                    hovertemplate='%{label}: %{percent:.1%}'
                )
                
                st.plotly_chart(fig, use_container_width=True)
            else:
                st.info("Could not calculate portfolio allocation. This may be due to missing stock data.")
                st.write("Try refreshing the stock data using the button in the sidebar.")
        except Exception as e:
            st.error(f"Error generating portfolio allocation chart: {e}")
            st.info("Try refreshing the stock data using the button in the sidebar.")
    
    # Investment Recommendations Section
    if st.session_state.portfolio.stocks:
        st.header("Investment Recommendations")
        st.write("Based on technical analysis of market trends and candlestick patterns.")
        
        # Get all recommendations
        all_recommendations = st.session_state.portfolio.get_all_recommendations()
        
        if all_recommendations:
            # Create a table of recommendations
            rec_data = []
            
            for rec in all_recommendations:
                # Format recommendation with emoji
                if rec.get('action', rec.get('recommendation', 'HOLD')).upper() == 'BUY':
                    action = "🟢 Buy"
                elif rec.get('action', rec.get('recommendation', 'HOLD')).upper() == 'SELL':
                    action = "🔴 Sell"
                elif rec.get('action', rec.get('recommendation', 'HOLD')).upper() == 'HOLD':
                    action = "🟡 Hold"
                else:
                    action = "⚪ Avoid"
                    
                # Format confidence as percentage
                confidence = f"{rec['confidence']:.0%}"
                
                rec_data.append([
                    rec['ticker'],
                    rec['quantity'],
                    action,
                    confidence,
                    rec['reason']
                ])
            
            # Create a DataFrame for display
            rec_df = pd.DataFrame(
                rec_data,
                columns=[
                    "Ticker",
                    "Quantity",
                    "Recommendation",
                    "Confidence",
                    "Reason"
                ]
            )
            
            st.dataframe(rec_df, use_container_width=True)
            
            # Show detailed recommendations for each stock
            st.subheader("Detailed Investment Advice")
            
            # Create tabs for the detailed recommendations
            rec_tabs = st.tabs([f"{rec['ticker']} - {rec.get('action', rec.get('recommendation', 'HOLD')).upper().upper()}" for rec in all_recommendations])
            
            for i, rec in enumerate(all_recommendations):
                with rec_tabs[i]:
                    col1, col2 = st.columns([1, 2])
                    
                    with col1:
                        # Show trend icon
                        # Handle missing 'trend' key
                        trend = rec.get('trend', 'neutral')
                        if trend == 'bullish':
                            st.markdown("### 📈 Bullish Trend")
                        elif trend == 'bearish':
                            st.markdown("### 📉 Bearish Trend")
                        else:
                            st.markdown("### ↔️ Sideways Trend")
                            
                        # Show recommendation with confidence
                        rec_color = "green" if rec.get('action', rec.get('recommendation', 'HOLD')).upper() == 'BUY' else "red" if rec.get('action', rec.get('recommendation', 'HOLD')).upper() == 'SELL' else "orange"
                        st.markdown(f"**Recommendation:** <span style='color:{rec_color}'>{rec.get('action', rec.get('recommendation', 'HOLD')).upper().upper()}</span> ({rec['confidence']:.0%} confidence)", unsafe_allow_html=True)
                        
                        # Display patterns if any
                        # Handle missing 'patterns' key
                        patterns = rec.get('patterns', [])
                        if patterns:
                            st.markdown("**Detected Patterns:**")
                            for pattern in patterns:
                                signal_color = "green" if "bullish" in pattern['signal'] else "red" if "bearish" in pattern['signal'] else "gray"
                                st.markdown(f"- <span style='color:{signal_color}'>{pattern['name']}</span> ({pattern['signal']})", unsafe_allow_html=True)
                    
                    with col2:
                        # Display the advice
                        st.markdown("### Investment Advice")
                        st.markdown(rec.get('advice', rec.get('reason', 'No specific advice available')))
                        
                        # Show reasoning
                        st.markdown("### Analysis Summary")
                        st.markdown(rec['reason'])
        else:
            st.info("Unable to generate recommendations. This may be due to insufficient data or API rate limits.")
            st.write("Try refreshing the stock data using the button in the sidebar.")
    
    # Individual Stocks Section
    st.header("Individual Stocks")
    
    # Create tabs for each stock
    if st.session_state.portfolio.stocks:
        stock_tabs = st.tabs(list(st.session_state.portfolio.stocks.keys()))
        
        for i, ticker in enumerate(st.session_state.portfolio.stocks.keys()):
            with stock_tabs[i]:
                stock_info = stock_data.get_alpha_vantage_stock_info(ticker)
                stock_data_df = st.session_state.portfolio.data.get(ticker)
                stock_metrics = st.session_state.portfolio.get_stock_metrics(ticker)
                
                if stock_info:
                    # Stock header with basic info
                    st.subheader(f"{stock_info['name']} ({ticker})")
                    st.caption(f"Sector: {stock_info['sector']} | Industry: {stock_info['industry']}")
                    
                    # Show warning if we couldn't fetch data
                    if stock_data_df is None or stock_data_df.empty:
                        st.warning(f"Could not fetch price data for {ticker}. This could be due to Yahoo Finance API rate limits. Please try again later or check the ticker symbol.")
                    
                    # Current metrics
                    col1, col2, col3, col4 = st.columns(4)
                    
                    # Only show metrics if we have data
                    if stock_metrics:
                        with col1:
                            st.metric(
                                "Current Price",
                                f"${stock_metrics['latest_price']:.2f}" if stock_metrics.get('latest_price') is not None else "N/A",
                                f"{stock_metrics['daily_change']:.2%}" if stock_metrics.get('daily_change') is not None else None
                            )
                        
                        with col2:
                            st.metric(
                                "Daily Change",
                                f"${stock_metrics['daily_change_value']:.2f}" if stock_metrics.get('daily_change_value') is not None else "N/A",
                                f"{stock_metrics['daily_change']:.2%}" if stock_metrics.get('daily_change') is not None else None
                            )
                        
                        with col3:
                            st.metric(
                                "Weekly Change",
                                f"${stock_metrics['weekly_change_value']:.2f}" if stock_metrics.get('weekly_change_value') is not None else "N/A",
                                f"{stock_metrics['weekly_change']:.2%}" if stock_metrics.get('weekly_change') is not None else None
                            )
                        
                        with col4:
                            st.metric(
                                "Monthly Change",
                                f"${stock_metrics['monthly_change_value']:.2f}" if stock_metrics.get('monthly_change_value') is not None else "N/A",
                                f"{stock_metrics['monthly_change']:.2%}" if stock_metrics.get('monthly_change') is not None else None
                            )
                    else:
                        # If no metrics, show placeholders
                        with col1:
                            st.metric("Current Price", "N/A")
                        with col2:
                            st.metric("Daily Change", "N/A")
                        with col3:
                            st.metric("Weekly Change", "N/A")
                        with col4:
                            st.metric("Monthly Change", "N/A")
                    
                    # Only show charts if we have data
                    if stock_data_df is not None and not stock_data_df.empty:
                        # Stock price chart
                        fig = go.Figure()
                        
                        fig.add_trace(
                            go.Scatter(
                                x=stock_data_df.index,
                                y=stock_data_df['Close'],
                                mode='lines',
                                name='Close Price',
                                line=dict(color='blue')
                            )
                        )
                        
                        fig.update_layout(
                            title=f"{ticker} Price History ({time_options[selected_period]})",
                            xaxis_title="Date",
                            yaxis_title="Price ($)",
                            hovermode="x unified"
                        )
                        
                        st.plotly_chart(fig, use_container_width=True)
                        
                        # Cumulative return chart
                        fig_return = go.Figure()
                        
                        fig_return.add_trace(
                            go.Scatter(
                                x=stock_data_df.index,
                                y=stock_data_df['Cumulative_Return'],
                                mode='lines',
                                name='Cumulative Return',
                                line=dict(color='green')
                            )
                        )
                        
                        fig_return.update_layout(
                            title=f"{ticker} Cumulative Return ({time_options[selected_period]})",
                            xaxis_title="Date",
                            yaxis_title="Return",
                            hovermode="x unified"
                        )
                        
                        # Update y-axis format to percentage
                        fig_return.update_traces(
                            hovertemplate='%{x}<br>Return: %{y:.2%}<extra></extra>'
                        )
                        fig_return.update_layout(yaxis_tickformat='.1%')
                        
                        st.plotly_chart(fig_return, use_container_width=True)
                    else:
                        # Show message if no data is available
                        st.info("No price history data available to display charts.")
                        st.write("Try refreshing the stock data using the button in the sidebar.")
                    
                    # Technical Analysis Section
                    if stock_data_df is not None and not stock_data_df.empty:
                        st.subheader("Technical Analysis")
                        
                        # Get trend analysis and candlestick patterns
                        trend_data = st.session_state.portfolio.get_trend_analysis(ticker)
                        patterns = st.session_state.portfolio.get_candlestick_patterns(ticker)
                        levels = st.session_state.portfolio.get_support_resistance_levels(ticker)
                        
                        # Display trend information
                        if trend_data:
                            col1, col2 = st.columns(2)
                            
                            with col1:
                                st.markdown("### Market Trend")
                                
                                # Show trend with appropriate emoji and color
                                if trend_data['trend'] == 'bullish':
                                    st.markdown("**Current Trend:** 📈 <span style='color:green'>Bullish</span>", unsafe_allow_html=True)
                                elif trend_data['trend'] == 'bearish':
                                    st.markdown("**Current Trend:** 📉 <span style='color:red'>Bearish</span>", unsafe_allow_html=True)
                                else:
                                    st.markdown("**Current Trend:** ↔️ <span style='color:orange'>Sideways</span>", unsafe_allow_html=True)
                                
                                # Show trend strength
                                st.progress(trend_data['strength'], text=f"Trend Strength: {trend_data['strength']:.0%}")
                                
                                # Show volatility
                                st.metric("Volatility (Annual)", f"{trend_data['volatility']:.1%}")
                                
                                # Show moving averages
                                st.markdown(f"**Short-term MA:** ${trend_data.get('short_ma', 0.0):.2f}")
                                st.markdown(f"**Long-term MA:** ${trend_data.get('long_ma', 0.0):.2f}")
                            
                            with col2:
                                # Support and Resistance levels
                                if levels:
                                    st.markdown("### Support & Resistance")
                                    
                                    # Current price
                                    st.markdown(f"**Current Price:** ${levels['current_price']:.2f}")
                                    
                                    # Support levels
                                    if levels['support_levels']:
                                        supports = ", ".join([f"${level:.2f}" for level in levels['support_levels']])
                                        st.markdown(f"**Support Levels:** {supports}")
                                    
                                    # Resistance levels
                                    if levels['resistance_levels']:
                                        resistances = ", ".join([f"${level:.2f}" for level in levels['resistance_levels']])
                                        st.markdown(f"**Resistance Levels:** {resistances}")
                        
                        # Display candlestick patterns
                        if patterns:
                            st.markdown("### Candlestick Patterns")
                            
                            for pattern in patterns:
                                signal_color = "green" if "bullish" in pattern['signal'] else "red" if "bearish" in pattern['signal'] else "gray"
                                signal_emoji = "🔼" if "bullish" in pattern['signal'] else "🔽" if "bearish" in pattern['signal'] else "◀️▶️"
                                
                                st.markdown(f"**{signal_emoji} {pattern['name']}** - <span style='color:{signal_color}'>{pattern['signal']}</span>", unsafe_allow_html=True)
                                st.caption(pattern['description'])
                    
                    # Additional stock information
                    st.subheader("Stock Details")
                    
                    col1, col2, col3 = st.columns(3)
                    
                    with col1:
                        st.metric("Open", f"${stock_info['open']}" if stock_info['open'] != 'N/A' else "N/A")
                        st.metric("Previous Close", f"${stock_info['previous_close']}" if stock_info['previous_close'] != 'N/A' else "N/A")
                        st.metric("Volume", f"{stock_info['volume']:,}" if stock_info['volume'] != 'N/A' else "N/A")
                    
                    with col2:
                        st.metric("Day High", f"${stock_info['day_high']}" if stock_info['day_high'] != 'N/A' else "N/A")
                        st.metric("Day Low", f"${stock_info['day_low']}" if stock_info['day_low'] != 'N/A' else "N/A")
                        st.metric("P/E Ratio", f"{stock_info['pe_ratio']:.2f}" if stock_info['pe_ratio'] != 'N/A' else "N/A")
                    
                    with col3:
                        st.metric("52 Week High", f"${stock_info['52wk_high']}" if stock_info['52wk_high'] != 'N/A' else "N/A")
                        st.metric("52 Week Low", f"${stock_info['52wk_low']}" if stock_info['52wk_low'] != 'N/A' else "N/A")
                        st.metric("Dividend Yield", f"{stock_info['dividend_yield']:.2%}" if stock_info['dividend_yield'] != 'N/A' else "N/A")
                else:
                    st.error(f"Could not load data for {ticker}. Please check the ticker symbol and try again.")

elif page == "Watchlist":
    # WATCHLIST PAGE
    st.title("Stock Watchlist")
    st.markdown("Track stocks you're interested in without adding them to your portfolio")
    
    # Watchlist form
    with st.form("add_watchlist_form"):
        st.subheader("Add Stock to Watchlist")
        
        new_ticker = st.text_input("Stock Ticker Symbol (e.g., AAPL)").upper()
        notes = st.text_area("Notes (optional)", placeholder="Add your notes about this stock here...")
        price_target = st.number_input("Price Target ($)", min_value=0.0, step=1.0, value=0.0)
        
        if price_target == 0.0:
            price_target = None
            
        submit_button = st.form_submit_button("Add to Watchlist")
        
        if submit_button and new_ticker:
            success, message = st.session_state.portfolio.add_to_watchlist(new_ticker, notes, price_target)
            if success:
                st.success(message)
                st.session_state.portfolio.update_watchlist_data()
                st.rerun()
            else:
                st.error(message)
    
    # Display watchlist
    if not st.session_state.portfolio.watchlist:
        st.info("Your watchlist is empty. Add stocks to start tracking them.")
        
        # Show example tickers
        st.markdown("### Suggested Stocks to Watch:")
        
        ticker_cols = st.columns(2)
        for i, (ticker, name) in enumerate(popular_tickers.items()):
            with ticker_cols[i % 2]:
                st.write(f"**{ticker}**: {name}")
    else:
        # Watchlist overview
        st.subheader("Your Watchlist")
        
        # Create a table of watchlist items
        watchlist_data = []
        
        # Update watchlist data
        st.session_state.portfolio.update_watchlist_data()
        
        for ticker, item_info in st.session_state.portfolio.watchlist.items():
            # Get stock data and metrics
            stock_data_df = st.session_state.portfolio.watchlist_data.get(ticker)
            metrics = st.session_state.portfolio.get_watchlist_metrics(ticker)
            
            # Get current price and calculate % from target
            current_price = "N/A"
            price_diff = "N/A"
            price_diff_pct = "N/A"
            
            if metrics and metrics.get('latest_price'):
                current_price = f"${metrics['latest_price']:.2f}"
                
                # Calculate distance from price target
                if item_info['price_target']:
                    diff = item_info['price_target'] - metrics['latest_price']
                    diff_pct = diff / metrics['latest_price']
                    price_diff = f"${diff:.2f}"
                    price_diff_pct = f"{diff_pct:.1%}"
            
            # Add to table data
            watchlist_data.append({
                "Ticker": ticker,
                "Current Price": current_price,
                "Price Target": f"${item_info['price_target']:.2f}" if item_info['price_target'] else "Not set",
                "Distance to Target": price_diff if item_info['price_target'] else "N/A",
                "% to Target": price_diff_pct if item_info['price_target'] else "N/A",
                "Notes": item_info['notes'] if item_info['notes'] else ""
            })
        
        # Convert to DataFrame
        watchlist_df = pd.DataFrame(watchlist_data)
        
        # Show the watchlist table
        st.dataframe(watchlist_df, use_container_width=True)
        
        # Detailed stock views
        st.subheader("Watchlist Stock Details")
        
        # Create tabs for each stock
        stock_tabs = st.tabs(list(st.session_state.portfolio.watchlist.keys()))
        
        for i, ticker in enumerate(st.session_state.portfolio.watchlist.keys()):
            with stock_tabs[i]:
                stock_info = stock_data.get_alpha_vantage_stock_info(ticker)
                stock_data_df = st.session_state.portfolio.watchlist_data.get(ticker)
                stock_metrics = st.session_state.portfolio.get_watchlist_metrics(ticker)
                item_info = st.session_state.portfolio.watchlist[ticker]
                
                if stock_info:
                    # Actions row
                    col1, col2, col3 = st.columns([1, 1, 2])
                    
                    with col1:
                        if st.button("Remove from Watchlist", key=f"remove_watch_{ticker}"):
                            success, message = st.session_state.portfolio.remove_from_watchlist(ticker)
                            if success:
                                st.success(message)
                                st.rerun()
                            else:
                                st.error(message)
                    
                    with col2:
                        if st.button("Add to Portfolio", key=f"add_portfolio_{ticker}"):
                            success, message = st.session_state.portfolio.add_stock(ticker, 1)
                            if success:
                                st.success(message)
                                # Optionally remove from watchlist
                                # st.session_state.portfolio.remove_from_watchlist(ticker)
                                st.rerun()
                            else:
                                st.error(message)
                    
                    # Stock header with basic info
                    st.subheader(f"{stock_info['name']} ({ticker})")
                    st.caption(f"Sector: {stock_info['sector']} | Industry: {stock_info['industry']}")
                    
                    # Show warning if we couldn't fetch data
                    if stock_data_df is None or stock_data_df.empty:
                        st.warning(f"Could not fetch price data for {ticker}. This could be due to Yahoo Finance API rate limits. Please try again later or check the ticker symbol.")
                    
                    # Notes and Price Target
                    notes_col, target_col = st.columns(2)
                    
                    with notes_col:
                        st.subheader("Your Notes")
                        new_notes = st.text_area(
                            "Edit Notes", 
                            value=item_info["notes"] if item_info["notes"] else "",
                            key=f"notes_{ticker}"
                        )
                        
                        if new_notes != item_info["notes"]:
                            st.session_state.portfolio.update_watchlist_item(ticker, notes=new_notes)
                            st.info("Notes updated!")
                    
                    with target_col:
                        st.subheader("Price Target")
                        new_target = st.number_input(
                            "Set Price Target ($)", 
                            min_value=0.0, 
                            value=item_info["price_target"] if item_info["price_target"] else 0.0,
                            key=f"target_{ticker}"
                        )
                        
                        if new_target == 0.0:
                            new_target = None
                            
                        if new_target != item_info["price_target"]:
                            st.session_state.portfolio.update_watchlist_item(ticker, price_target=new_target)
                            st.info("Price target updated!")
                    
                    # Technical Analysis
                    if stock_data_df is not None and not stock_data_df.empty:
                        st.subheader("Technical Analysis")
                        
                        # Get trend analysis and candlestick patterns
                        trend_data = st.session_state.portfolio.get_watchlist_trend_analysis(ticker)
                        patterns = st.session_state.portfolio.get_watchlist_patterns(ticker)
                        levels = st.session_state.portfolio.get_watchlist_support_resistance(ticker)
                        
                        # Current metrics
                        col1, col2, col3, col4 = st.columns(4)
                        
                        # Only show metrics if we have data
                        if stock_metrics:
                            with col1:
                                st.metric(
                                    "Current Price",
                                    f"${stock_metrics['latest_price']:.2f}" if stock_metrics.get('latest_price') is not None else "N/A",
                                    f"{stock_metrics['daily_change']:.2%}" if stock_metrics.get('daily_change') is not None else None
                                )
                            
                            with col2:
                                st.metric(
                                    "Daily Change",
                                    f"${stock_metrics['daily_change_value']:.2f}" if stock_metrics.get('daily_change_value') is not None else "N/A",
                                    f"{stock_metrics['daily_change']:.2%}" if stock_metrics.get('daily_change') is not None else None
                                )
                            
                            with col3:
                                st.metric(
                                    "Weekly Change",
                                    f"${stock_metrics['weekly_change_value']:.2f}" if stock_metrics.get('weekly_change_value') is not None else "N/A",
                                    f"{stock_metrics['weekly_change']:.2%}" if stock_metrics.get('weekly_change') is not None else None
                                )
                            
                            with col4:
                                st.metric(
                                    "Monthly Change",
                                    f"${stock_metrics['monthly_change_value']:.2f}" if stock_metrics.get('monthly_change_value') is not None else "N/A",
                                    f"{stock_metrics['monthly_change']:.2%}" if stock_metrics.get('monthly_change') is not None else None
                                )
                        else:
                            # If no metrics, show placeholders
                            with col1:
                                st.metric("Current Price", "N/A")
                            with col2:
                                st.metric("Daily Change", "N/A")
                            with col3:
                                st.metric("Weekly Change", "N/A")
                            with col4:
                                st.metric("Monthly Change", "N/A")
                        
                        # Display trend information
                        if trend_data:
                            col1, col2 = st.columns(2)
                            
                            with col1:
                                st.markdown("### Market Trend")
                                
                                # Show trend with appropriate emoji and color
                                if trend_data['trend'] == 'bullish':
                                    st.markdown("**Current Trend:** 📈 <span style='color:green'>Bullish</span>", unsafe_allow_html=True)
                                elif trend_data['trend'] == 'bearish':
                                    st.markdown("**Current Trend:** 📉 <span style='color:red'>Bearish</span>", unsafe_allow_html=True)
                                else:
                                    st.markdown("**Current Trend:** ↔️ <span style='color:orange'>Sideways</span>", unsafe_allow_html=True)
                                
                                # Show trend strength
                                st.progress(trend_data['strength'], text=f"Trend Strength: {trend_data['strength']:.0%}")
                                
                                # Show volatility
                                st.metric("Volatility (Annual)", f"{trend_data['volatility']:.1%}")
                                
                                # Show moving averages
                                st.markdown(f"**Short-term MA:** ${trend_data.get('short_ma', 0.0):.2f}")
                                st.markdown(f"**Long-term MA:** ${trend_data.get('long_ma', 0.0):.2f}")
                            
                            with col2:
                                # Support and Resistance levels
                                if levels:
                                    st.markdown("### Support & Resistance")
                                    
                                    # Current price
                                    st.markdown(f"**Current Price:** ${levels['current_price']:.2f}")
                                    
                                    # Support levels
                                    if levels['support_levels']:
                                        supports = ", ".join([f"${level:.2f}" for level in levels['support_levels']])
                                        st.markdown(f"**Support Levels:** {supports}")
                                    
                                    # Resistance levels
                                    if levels['resistance_levels']:
                                        resistances = ", ".join([f"${level:.2f}" for level in levels['resistance_levels']])
                                        st.markdown(f"**Resistance Levels:** {resistances}")
                        
                        # Display candlestick patterns
                        if patterns:
                            st.markdown("### Candlestick Patterns")
                            
                            for pattern in patterns:
                                signal_color = "green" if "bullish" in pattern['signal'] else "red" if "bearish" in pattern['signal'] else "gray"
                                signal_emoji = "🔼" if "bullish" in pattern['signal'] else "🔽" if "bearish" in pattern['signal'] else "◀️▶️"
                                
                                st.markdown(f"**{signal_emoji} {pattern['name']}** - <span style='color:{signal_color}'>{pattern['signal']}</span>", unsafe_allow_html=True)
                                st.caption(pattern['description'])
                        
                        # Stock price chart
                        st.subheader("Price Chart")
                        fig = go.Figure()
                        
                        fig.add_trace(
                            go.Scatter(
                                x=stock_data_df.index,
                                y=stock_data_df['Close'],
                                mode='lines',
                                name='Close Price',
                                line=dict(color='blue')
                            )
                        )
                        
                        # Add price target line if set
                        if item_info['price_target']:
                            fig.add_hline(
                                y=item_info['price_target'],
                                line_dash="dash",
                                line_color="green",
                                annotation_text=f"Price Target: ${item_info['price_target']:.2f}"
                            )
                        
                        fig.update_layout(
                            title=f"{ticker} Price History ({time_options[selected_period]})",
                            xaxis_title="Date",
                            yaxis_title="Price ($)",
                            hovermode="x unified"
                        )
                        
                        st.plotly_chart(fig, use_container_width=True)
                    
                    # Stock Details
                    st.subheader("Stock Details")
                    col1, col2, col3 = st.columns(3)
                    
                    with col1:
                        st.metric("Open", f"${stock_info['open']}" if stock_info['open'] != 'N/A' else "N/A")
                        st.metric("Previous Close", f"${stock_info['previous_close']}" if stock_info['previous_close'] != 'N/A' else "N/A")
                        st.metric("Volume", f"{stock_info['volume']:,}" if stock_info['volume'] != 'N/A' else "N/A")
                    
                    with col2:
                        st.metric("Day High", f"${stock_info['day_high']}" if stock_info['day_high'] != 'N/A' else "N/A")
                        st.metric("Day Low", f"${stock_info['day_low']}" if stock_info['day_low'] != 'N/A' else "N/A")
                        st.metric("P/E Ratio", f"{stock_info['pe_ratio']:.2f}" if stock_info['pe_ratio'] != 'N/A' else "N/A")
                    
                    with col3:
                        st.metric("52 Week High", f"${stock_info['52wk_high']}" if stock_info['52wk_high'] != 'N/A' else "N/A")
                        st.metric("52 Week Low", f"${stock_info['52wk_low']}" if stock_info['52wk_low'] != 'N/A' else "N/A")
                        st.metric("Dividend Yield", f"{stock_info['dividend_yield']:.2%}" if stock_info['dividend_yield'] != 'N/A' else "N/A")

elif page == "Stock Search":
    # STOCK SEARCH PAGE
    st.header("🔍 Stock Search & Analysis")
    st.markdown("Quickly search for any stock to get detailed information and investment advice")
    
    # Search form with auto-suggestions
    search_col1, search_col2 = st.columns([3, 1])
    
    with search_col1:
        search_ticker = st.text_input("Enter a Stock Ticker Symbol (e.g., AAPL, MSFT)", "").upper()
    
    with search_col2:
        search_button = st.button("Analyze Stock", use_container_width=True)
    
    # Display popular stock suggestions
    st.markdown("### Popular Stocks")
    suggestion_cols = st.columns(5)
    for i, (ticker, name) in enumerate(list(popular_tickers.items())[:10]):
        col_index = i % 5
        with suggestion_cols[col_index]:
            if st.button(f"{ticker}", key=f"search_sugg_{ticker}", use_container_width=True):
                search_ticker = ticker
                search_button = True
    
    # Process the search
    if search_button and search_ticker:
        try:
            # Validate ticker and get data
            is_valid = stock_data.validate_ticker(search_ticker)
            
            if is_valid:
                # Get basic stock info
                stock_info = stock_data.get_alpha_vantage_stock_info(search_ticker)
                
                if stock_info:
                    # Basic stock information card
                    st.markdown(f"""
                    <div class="recommendation-card">
                        <h2>{search_ticker} - {stock_info.get('name', 'N/A')}</h2>
                        <p>
                            <strong>Sector:</strong> {stock_info.get('sector', 'N/A')} | 
                            <strong>Industry:</strong> {stock_info.get('industry', 'N/A')}
                        </p>
                    </div>
                    """, unsafe_allow_html=True)
                    
                    # Create tabs for different views
                    search_tabs = st.tabs([
                        "📊 Overview", 
                        "📈 Performance Chart", 
                        "📝 Investment Advice",
                        "🔍 Technical Analysis"
                    ])
                    
                    # Get stock data for the analysis
                    data = stock_data.get_stock_data(search_ticker, period=st.session_state.time_period)
                    
                    with search_tabs[0]:  # OVERVIEW TAB
                        if data is not None and not data.empty:
                            # Stats row with key metrics
                            col1, col2, col3, col4 = st.columns(4)
                            
                            with col1:
                                current_price = data['Close'].iloc[-1]
                                prev_price = data['Close'].iloc[-2] if len(data) > 1 else current_price
                                price_change = (current_price - prev_price) / prev_price
                                
                                st.metric(
                                    "Current Price",
                                    f"${current_price:.2f}",
                                    f"{price_change:.2%}",
                                    delta_color="normal"
                                )
                            
                            with col2:
                                if 'High' in data.columns and 'Low' in data.columns:
                                    period_high = data['High'].max()
                                    period_low = data['Low'].min()
                                    
                                    st.metric(
                                        f"{st.session_state.time_period} Range",
                                        f"${period_high:.2f} - ${period_low:.2f}"
                                    )
                            
                            with col3:
                                if 'Volume' in data.columns:
                                    avg_volume = data['Volume'].mean()
                                    volume_unit = "M" if avg_volume > 1000000 else "K"
                                    avg_volume_display = f"{avg_volume / 1000000:.2f}M" if avg_volume > 1000000 else f"{avg_volume / 1000:.2f}K"
                                    
                                    st.metric(
                                        "Avg. Volume",
                                        avg_volume_display
                                    )
                            
                            with col4:
                                # Calculate volatility
                                if len(data) > 1:
                                    daily_returns = data['Close'].pct_change().dropna()
                                    volatility = daily_returns.std() * (252 ** 0.5)  # Annualized
                                    
                                    st.metric(
                                        "Volatility",
                                        f"{volatility:.2%}"
                                    )
                            
                            # Show more detailed stock information
                            st.markdown("### Key Information")
                            
                            info_col1, info_col2 = st.columns(2)
                            
                            with info_col1:
                                # Use the keys that match what we have in our get_stock_info function
                                st.markdown(f"**Market Cap:** {stock_info.get('market_cap', 'N/A')}")
                                st.markdown(f"**P/E Ratio:** {stock_info.get('pe_ratio', 'N/A')}")
                                
                                # Get additional info directly from the yfinance API for other metrics
                                try:
                                    ticker_obj = yf.Ticker(search_ticker)
                                    extra_info = ticker_obj.info
                                    eps = extra_info.get('trailingEps', 'N/A')
                                    st.markdown(f"**EPS:** {eps}")
                                    
                                    div_yield = stock_info.get('dividend_yield', None)
                                    if div_yield not in [None, 'N/A']:
                                        st.markdown(f"**Dividend Yield:** {div_yield:.2%}")
                                    else:
                                        st.markdown(f"**Dividend Yield:** N/A")
                                except:
                                    st.markdown(f"**EPS:** N/A")
                                    st.markdown(f"**Dividend Yield:** N/A")
                            
                            with info_col2:
                                st.markdown(f"**52-Week High:** ${stock_info.get('52wk_high', 'N/A')}")
                                st.markdown(f"**52-Week Low:** ${stock_info.get('52wk_low', 'N/A')}")
                                
                                # Try to get moving averages from the yfinance API
                                try:
                                    ticker_obj = yf.Ticker(search_ticker)
                                    extra_info = ticker_obj.info
                                    ma_50 = extra_info.get('fiftyDayAverage', 'N/A')
                                    ma_200 = extra_info.get('twoHundredDayAverage', 'N/A')
                                    
                                    if ma_50 != 'N/A':
                                        st.markdown(f"**50-Day MA:** ${ma_50:.2f}")
                                    else:
                                        st.markdown(f"**50-Day MA:** N/A")
                                        
                                    if ma_200 != 'N/A':
                                        st.markdown(f"**200-Day MA:** ${ma_200:.2f}")
                                    else:
                                        st.markdown(f"**200-Day MA:** N/A")
                                except:
                                    st.markdown(f"**50-Day MA:** N/A")
                                    st.markdown(f"**200-Day MA:** N/A")
                            
                            # Company description
                            try:
                                ticker_obj = yf.Ticker(search_ticker)
                                extra_info = ticker_obj.info
                                if 'longBusinessSummary' in extra_info:
                                    st.markdown("### About the Company")
                                    st.markdown(extra_info['longBusinessSummary'])
                                else:
                                    st.info("No company description available.")
                            except Exception as e:
                                st.info("Company description not available.")
                        else:
                            st.warning(f"No data available for {search_ticker}. Try a different time period.")
                    
                    with search_tabs[1]:  # PERFORMANCE CHART TAB
                        if data is not None and not data.empty:
                            # Performance chart options
                            chart_type = st.radio(
                                "Chart Type",
                                ["Candlestick", "Line", "OHLC"],
                                horizontal=True
                            )
                            
                            # Create figure based on chart type
                            fig = go.Figure()
                            
                            if chart_type == "Candlestick":
                                fig.add_trace(go.Candlestick(
                                    x=data.index,
                                    open=data['Open'],
                                    high=data['High'],
                                    low=data['Low'],
                                    close=data['Close'],
                                    name='Price'
                                ))
                            elif chart_type == "OHLC":
                                fig.add_trace(go.Ohlc(
                                    x=data.index,
                                    open=data['Open'],
                                    high=data['High'],
                                    low=data['Low'],
                                    close=data['Close'],
                                    name='Price'
                                ))
                            else:  # Line chart
                                fig.add_trace(go.Scatter(
                                    x=data.index,
                                    y=data['Close'],
                                    mode='lines',
                                    name='Close Price',
                                    line=dict(color='blue', width=2)
                                ))
                            
                            # Add moving averages
                            show_mas = st.checkbox("Show Moving Averages", value=True)
                            
                            if show_mas and len(data) > 20:
                                # 20-day MA
                                if len(data) >= 20:
                                    data['MA20'] = data['Close'].rolling(window=20).mean()
                                    fig.add_trace(go.Scatter(
                                        x=data.index,
                                        y=data['MA20'],
                                        mode='lines',
                                        name='20-day MA',
                                        line=dict(color='orange', width=2)
                                    ))
                                
                                # 50-day MA
                                if len(data) >= 50:
                                    data['MA50'] = data['Close'].rolling(window=50).mean()
                                    fig.add_trace(go.Scatter(
                                        x=data.index,
                                        y=data['MA50'],
                                        mode='lines',
                                        name='50-day MA',
                                        line=dict(color='green', width=2)
                                    ))
                                
                                # 200-day MA
                                if len(data) >= 200:
                                    data['MA200'] = data['Close'].rolling(window=200).mean()
                                    fig.add_trace(go.Scatter(
                                        x=data.index,
                                        y=data['MA200'],
                                        mode='lines',
                                        name='200-day MA',
                                        line=dict(color='red', width=2)
                                    ))
                            
                            # Add volume as a subplot
                            show_volume = st.checkbox("Show Volume", value=True)
                            
                            if show_volume:
                                fig.add_trace(go.Bar(
                                    x=data.index,
                                    y=data['Volume'],
                                    name='Volume',
                                    marker=dict(color='rgba(0, 0, 255, 0.3)'),
                                    opacity=0.3
                                ))
                            
                            # Update layout
                            fig.update_layout(
                                title=f"{search_ticker} Stock Price Performance ({st.session_state.time_period})",
                                xaxis_title="Date",
                                yaxis_title="Price (USD)",
                                height=600,
                                xaxis_rangeslider_visible=False
                            )
                            
                            st.plotly_chart(fig, use_container_width=True)
                            
                            # Performance metrics
                            try:
                                metrics = stock_data.calculate_metrics(data)
                                
                                if metrics:
                                    st.subheader("Performance Metrics")
                                    
                                    metric_cols = st.columns(4)
                                    
                                    with metric_cols[0]:
                                        st.metric(
                                            "Total Return",
                                            f"{metrics['total_return']:.2%}",
                                            delta=None
                                        )
                                    
                                    with metric_cols[1]:
                                        st.metric(
                                            "Annualized Return",
                                            f"{metrics['annualized_return']:.2%}",
                                            delta=None
                                        )
                                    
                                    with metric_cols[2]:
                                        st.metric(
                                            "Volatility",
                                            f"{metrics['volatility']:.2%}",
                                            delta=None
                                        )
                                    
                                    with metric_cols[3]:
                                        st.metric(
                                            "Sharpe Ratio",
                                            f"{metrics['sharpe_ratio']:.2f}",
                                            delta=None
                                        )
                            except Exception as e:
                                st.warning(f"Could not display some performance metrics: {e}")
                                st.info("This may be due to limited data for the selected time period.")
                        else:
                            st.warning(f"No data available for {search_ticker}. Try a different time period.")
                    
                    with search_tabs[2]:  # INVESTMENT ADVICE TAB
                        if data is not None and not data.empty:
                            # Get recommendations using market_analysis functions
                            try:
                                import market_analysis
                                
                                recommendation = market_analysis.generate_stock_recommendation(search_ticker, data)
                                
                                if recommendation:
                                    # Determine card style based on recommendation
                                    card_class = "recommendation-card"
                                    if recommendation['recommendation'] == 'BUY':
                                        card_class += " rec-buy"
                                    elif recommendation['recommendation'] == 'SELL':
                                        card_class += " rec-sell"
                                    elif recommendation['recommendation'] == 'HOLD':
                                        card_class += " rec-hold"
                                    
                                    # Large recommendation card
                                    st.markdown(f"""
                                    <div class="{card_class}">
                                        <h2>Recommendation: {recommendation['recommendation'].upper()}</h2>
                                        <p>Confidence: <strong>{recommendation['confidence']:.0%}</strong></p>
                                    </div>
                                    """, unsafe_allow_html=True)
                                    
                                    # Display detailed analysis
                                    advice_col1, advice_col2 = st.columns([1, 2])
                                    
                                    with advice_col1:
                                        # Market trend indicators
                                        st.subheader("Market Trend")
                                        trend = recommendation.get('trend', 'neutral')
                                        
                                        if trend == 'bullish':
                                            st.markdown('<p class="bullish">📈 BULLISH TREND</p>', unsafe_allow_html=True)
                                        elif trend == 'bearish':
                                            st.markdown('<p class="bearish">📉 BEARISH TREND</p>', unsafe_allow_html=True)
                                        else:
                                            st.markdown('<p class="neutral">↔️ SIDEWAYS TREND</p>', unsafe_allow_html=True)
                                        
                                        # Display patterns if any
                                        patterns = recommendation.get('patterns', [])
                                        if patterns:
                                            st.subheader("Detected Patterns")
                                            for pattern in patterns:
                                                signal_color = "bullish" if "bullish" in pattern['signal'] else "bearish" if "bearish" in pattern['signal'] else "neutral"
                                                st.markdown(f'<p class="{signal_color}">• {pattern["name"]} - {pattern["signal"]}</p>', unsafe_allow_html=True)
                                        else:
                                            st.info("No significant patterns detected")
                                    
                                    with advice_col2:
                                        # Display the detailed investment advice
                                        st.subheader("Investment Advice")
                                        st.markdown(recommendation['advice'])
                                        
                                        # Summary points
                                        st.subheader("Key Points")
                                        st.markdown(recommendation.get('summary', "No summary available"))
                                    
                                    # Action buttons
                                    st.markdown("### Take Action")
                                    action_cols = st.columns([1, 1, 1])
                                    
                                    with action_cols[0]:
                                        if st.button(f"Add {search_ticker} to Portfolio", key="search_add_port", use_container_width=True):
                                            qty = 1  # Default quantity
                                            success, message = st.session_state.portfolio.add_stock(search_ticker, qty)
                                            if success:
                                                st.success(message)
                                            else:
                                                st.error(message)
                                    
                                    with action_cols[1]:
                                        if st.button(f"Add {search_ticker} to Watchlist", key="search_add_watch", use_container_width=True):
                                            try:
                                                st.session_state.portfolio.add_to_watchlist(search_ticker)
                                                st.success(f"{search_ticker} added to watchlist successfully!")
                                            except Exception as e:
                                                st.error(f"Error adding to watchlist: {e}")
                                    
                                    with action_cols[2]:
                                        if search_ticker in st.session_state.portfolio.stocks:
                                            if st.button(f"Remove {search_ticker}", key="search_remove", use_container_width=True):
                                                st.session_state.portfolio.remove_stock(search_ticker)
                                                st.success(f"{search_ticker} removed from portfolio")
                                        
                                else:
                                    st.warning("Unable to generate recommendations for this stock")
                            except Exception as e:
                                st.error(f"Error generating recommendation: {e}")
                                st.info("This may be due to insufficient data or API rate limits.")
                        else:
                            st.warning(f"No data available for {search_ticker}. Try a different time period.")
                    
                    with search_tabs[3]:  # TECHNICAL ANALYSIS TAB
                        if data is not None and not data.empty:
                            # Create tabs for different technical analysis views
                            tech_tabs = st.tabs([
                                "🔍 Support & Resistance", 
                                "📈 Trend Analysis", 
                                "🕯️ Candlestick Patterns"
                            ])
                            
                            with tech_tabs[0]:  # SUPPORT & RESISTANCE
                                try:
                                    import market_analysis
                                    
                                    levels = market_analysis.identify_support_resistance(data)
                                    
                                    if levels:
                                        st.subheader("Support and Resistance Levels")
                                        
                                        # Create chart with levels
                                        fig = go.Figure()
                                        fig.add_trace(go.Candlestick(
                                            x=data.index,
                                            open=data['Open'],
                                            high=data['High'],
                                            low=data['Low'],
                                            close=data['Close'],
                                            name='Price'
                                        ))
                                        
                                        # Add resistance levels
                                        for level in levels.get('resistance_levels', []):
                                            fig.add_shape(
                                                type='line',
                                                x0=data.index[0],
                                                y0=level,
                                                x1=data.index[-1],
                                                y1=level,
                                                line=dict(color='red', width=2, dash='dash'),
                                                name=f'Resistance ${level:.2f}'
                                            )
                                        
                                        # Add support levels
                                        for level in levels.get('support_levels', []):
                                            fig.add_shape(
                                                type='line',
                                                x0=data.index[0],
                                                y0=level,
                                                x1=data.index[-1],
                                                y1=level,
                                                line=dict(color='green', width=2, dash='dash'),
                                                name=f'Support ${level:.2f}'
                                            )
                                        
                                        # Update layout
                                        fig.update_layout(
                                            title=f"{search_ticker} with Support & Resistance Levels",
                                            xaxis_title="Date",
                                            yaxis_title="Price (USD)",
                                            height=500,
                                            xaxis_rangeslider_visible=False
                                        )
                                        
                                        st.plotly_chart(fig, use_container_width=True)
                                        
                                        # List the levels as text
                                        col1, col2 = st.columns(2)
                                        
                                        with col1:
                                            st.subheader("Resistance Levels")
                                            for i, level in enumerate(levels.get('resistance_levels', []), 1):
                                                st.markdown(f"**R{i}:** ${level:.2f}")
                                                
                                        with col2:
                                            st.subheader("Support Levels")
                                            for i, level in enumerate(levels.get('support_levels', []), 1):
                                                st.markdown(f"**S{i}:** ${level:.2f}")
                                        
                                        # Trading advice based on current price
                                        current_price = data['Close'].iloc[-1]
                                        st.markdown("### Price Level Analysis")
                                        
                                        resistance_levels = levels.get('resistance_levels', [])
                                        support_levels = levels.get('support_levels', [])
                                        
                                        closest_resistance = min(resistance_levels, key=lambda x: abs(x - current_price)) if resistance_levels else None
                                        closest_support = min(support_levels, key=lambda x: abs(x - current_price)) if support_levels else None
                                        
                                        if closest_resistance and closest_support:
                                            resistance_diff = (closest_resistance - current_price) / current_price
                                            support_diff = (current_price - closest_support) / current_price
                                            
                                            st.markdown(f"- Current price (${current_price:.2f}) is:")
                                            st.markdown(f"  - **{resistance_diff:.2%}** below closest resistance at **${closest_resistance:.2f}**")
                                            st.markdown(f"  - **{support_diff:.2%}** above closest support at **${closest_support:.2f}**")
                                            
                                            # Trading advice
                                            if resistance_diff < 0.03:  # Within 3% of resistance
                                                st.warning("⚠️ Price is near resistance - consider taking profits or waiting for breakout confirmation before buying")
                                            elif support_diff < 0.03:  # Within 3% of support
                                                st.info("💡 Price is near support - may be a good entry point if support holds")
                                    else:
                                        st.warning(f"Unable to calculate support and resistance levels for {search_ticker}")
                                except Exception as e:
                                    st.error(f"Error calculating support/resistance: {e}")
                            
                            with tech_tabs[1]:  # TREND ANALYSIS
                                try:
                                    import market_analysis
                                    
                                    trend_analysis = market_analysis.identify_trend(data)
                                    
                                    if trend_analysis:
                                        st.subheader("Current Market Trend")
                                        
                                        # Display trend with appropriate styling
                                        if trend_analysis['trend'] == 'bullish':
                                            st.markdown('<p class="bullish">📈 BULLISH TREND</p>', unsafe_allow_html=True)
                                            st.markdown(f"**Confidence:** {trend_analysis['strength']:.0%}")
                                            
                                            # Create a description if it doesn't exist
                                            description = trend_analysis.get('description', 
                                                f"The stock is in an uptrend with {trend_analysis['strength']:.0%} strength. "
                                                f"The price is currently above both short and long-term moving averages, "
                                                f"indicating positive momentum.")
                                            st.success(description)
                                            
                                        elif trend_analysis['trend'] == 'bearish':
                                            st.markdown('<p class="bearish">📉 BEARISH TREND</p>', unsafe_allow_html=True)
                                            st.markdown(f"**Confidence:** {trend_analysis['strength']:.0%}")
                                            
                                            # Create a description if it doesn't exist
                                            description = trend_analysis.get('description', 
                                                f"The stock is in a downtrend with {trend_analysis['strength']:.0%} strength. "
                                                f"The price is currently below both short and long-term moving averages, "
                                                f"indicating negative momentum.")
                                            st.error(description)
                                            
                                        else:
                                            st.markdown('<p class="neutral">↔️ SIDEWAYS TREND</p>', unsafe_allow_html=True)
                                            st.markdown(f"**Confidence:** {trend_analysis['strength']:.0%}")
                                            
                                            # Create a description if it doesn't exist
                                            description = trend_analysis.get('description', 
                                                f"The stock is trading sideways with {trend_analysis.get('volatility', 0.0):.0%} volatility. "
                                                f"The price is moving in a range without a clear direction, "
                                                f"indicating market indecision.")
                                            st.warning(description)
                                        
                                        # Create trend visualization chart
                                        fig = go.Figure()
                                        
                                        # Main price line
                                        fig.add_trace(go.Scatter(
                                            x=data.index,
                                            y=data['Close'],
                                            mode='lines',
                                            name='Close Price',
                                            line=dict(color='blue', width=2)
                                        ))
                                        
                                        # Add moving averages if available in trend analysis
                                        if 'short_ma_values' in trend_analysis and len(trend_analysis['short_ma_values']) > 0:
                                            fig.add_trace(go.Scatter(
                                                x=data.index[-len(trend_analysis['short_ma_values']):],
                                                y=trend_analysis['short_ma_values'],
                                                mode='lines',
                                                name=f"Short MA ({trend_analysis.get('window', 14)}-day)",
                                                line=dict(color='orange', width=2)
                                            ))
                                        
                                        if 'long_ma_values' in trend_analysis and len(trend_analysis['long_ma_values']) > 0:
                                            fig.add_trace(go.Scatter(
                                                x=data.index[-len(trend_analysis['long_ma_values']):],
                                                y=trend_analysis['long_ma_values'],
                                                mode='lines',
                                                name='Long MA (50-day)',
                                                line=dict(color='green', width=2)
                                            ))
                                        
                                        # Update layout
                                        fig.update_layout(
                                            title=f"{search_ticker} Trend Analysis",
                                            xaxis_title="Date",
                                            yaxis_title="Price (USD)",
                                            height=500
                                        )
                                        
                                        st.plotly_chart(fig, use_container_width=True)
                                        
                                        # Display moving averages as metrics
                                        st.subheader("Moving Averages")
                                        ma_cols = st.columns(3)
                                        
                                        with ma_cols[0]:
                                            st.metric(
                                                f"{trend_analysis.get('window', 14)}-day MA",
                                                f"${trend_analysis.get('short_ma', 0.0):.2f}"
                                            )
                                        
                                        with ma_cols[1]:
                                            st.metric(
                                                "50-day MA",
                                                f"${trend_analysis.get('long_ma', 0.0):.2f}"
                                            )
                                        
                                        with ma_cols[2]:
                                            # Calculate the cross indicator
                                            short_ma = trend_analysis.get('short_ma', 0)
                                            long_ma = trend_analysis.get('long_ma', 0)
                                            
                                            if short_ma > long_ma:
                                                st.markdown('<p class="bullish">📈 GOLDEN CROSS (Bullish)</p>', unsafe_allow_html=True)
                                            else:
                                                st.markdown('<p class="bearish">📉 DEATH CROSS (Bearish)</p>', unsafe_allow_html=True)
                                        
                                        # Trendline projection if available
                                        if 'trendline' in trend_analysis:
                                            st.subheader("Price Projection")
                                            st.markdown(f"Based on the current trend, the projected price movement is: **{trend_analysis['trendline']}**")
                                    else:
                                        st.warning(f"Unable to analyze trend for {search_ticker}")
                                except Exception as e:
                                    st.error(f"Error analyzing trend: {e}")
                            
                            with tech_tabs[2]:  # CANDLESTICK PATTERNS
                                try:
                                    import market_analysis
                                    
                                    patterns = market_analysis.identify_candlestick_patterns(data)
                                    
                                    if patterns:
                                        if len(patterns) > 0:
                                            st.subheader(f"Detected Candlestick Patterns")
                                            
                                            for pattern in patterns:
                                                # Create card for each pattern with appropriate styling
                                                if "bullish" in pattern['signal'].lower():
                                                    card_class = "recommendation-card rec-buy"
                                                elif "bearish" in pattern['signal'].lower():
                                                    card_class = "recommendation-card rec-sell"
                                                else:
                                                    card_class = "recommendation-card rec-hold"
                                                
                                                st.markdown(f"""
                                                <div class="{card_class}">
                                                    <h3>{pattern["name"]}</h3>
                                                    <p><strong>Signal:</strong> {pattern["signal"]}</p>
                                                """, unsafe_allow_html=True)
                                                
                                                if 'description' in pattern:
                                                    st.markdown(f"""
                                                    <p>{pattern['description']}</p>
                                                    """, unsafe_allow_html=True)
                                                
                                                st.markdown("</div>", unsafe_allow_html=True)
                                        else:
                                            st.info("No significant candlestick patterns detected in the recent price action.")
                                            
                                            # Offer explanation of common patterns
                                            with st.expander("Learn About Common Candlestick Patterns"):
                                                st.markdown("""
                                                ### Common Bullish Patterns
                                                - **Hammer**: A single candlestick pattern with a small body, little or no upper shadow, and a long lower shadow
                                                - **Bullish Engulfing**: A pattern where a small bearish candle is followed by a large bullish candle that completely 'engulfs' the previous day's candle
                                                - **Morning Star**: A three-candle pattern indicating a potential bottom and reversal
                                                
                                                ### Common Bearish Patterns
                                                - **Hanging Man**: Similar to the hammer but appears at the end of an uptrend
                                                - **Bearish Engulfing**: A pattern where a small bullish candle is followed by a large bearish candle that completely 'engulfs' the previous day's candle
                                                - **Evening Star**: A three-candle pattern indicating a potential top and reversal
                                                
                                                ### Neutral Patterns
                                                - **Doji**: A single candlestick with a very small body, indicating indecision
                                                - **Spinning Top**: A single candlestick with a small body centered between long upper and lower shadows
                                                """)
                                    else:
                                        st.warning(f"Unable to detect patterns for {search_ticker}")
                                except Exception as e:
                                    st.error(f"Error detecting patterns: {e}")
                        else:
                            st.warning(f"No data available for {search_ticker}. Try a different time period.")
                else:
                    st.error(f"Unable to retrieve information for {search_ticker}")
            else:
                st.error(f"Invalid ticker symbol: {search_ticker}")
                st.info("Please enter a valid stock ticker symbol (e.g., AAPL, MSFT, GOOGL)")
        except Exception as e:
            st.error(f"Error analyzing stock: {e}")
            st.info("Please try a different ticker symbol or time period.")
    else:
        # Default starting view when no search has been made
        st.info("Enter a stock ticker symbol above to get detailed information and investment advice.")
        
        # Show market overview
        st.markdown("### Market Overview")
        st.markdown("Try searching for one of these popular stocks to see detailed analysis:")
        
        # Create a grid of popular stock cards for suggestions
        overview_cols = st.columns(3)
        
        for i, (ticker, name) in enumerate(list(popular_tickers.items())[:6]):
            with overview_cols[i % 3]:
                st.markdown(f"""
                <div class="market-card">
                    <h3>{ticker}</h3>
                    <p>{name}</p>
                </div>
                """, unsafe_allow_html=True)
                
                if st.button(f"Analyze {ticker}", key=f"overview_{ticker}"):
                    search_ticker = ticker
                    search_button = True

# Footer
st.markdown("---")
st.caption("Data provided by Yahoo Finance. Last updated: " + datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
