import os
import sqlite3
from sqlalchemy import create_engine, Column, Integer, String, Float, MetaData, Table, Text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

# Create the database directory if it doesn't exist
os.makedirs("data", exist_ok=True)

# Define the database connection
DATABASE_URL = "sqlite:///data/portfolio.db"
engine = create_engine(DATABASE_URL)
Base = declarative_base()
Session = sessionmaker(bind=engine)

# Define models
class StockModel(Base):
    __tablename__ = "stocks"
    
    id = Column(Integer, primary_key=True)
    ticker = Column(String, nullable=False, unique=True)
    quantity = Column(Float, nullable=False)
    
    def __repr__(self):
        return f"<Stock(ticker='{self.ticker}', quantity={self.quantity})>"

class WatchlistModel(Base):
    __tablename__ = "watchlist"
    
    id = Column(Integer, primary_key=True)
    ticker = Column(String, nullable=False, unique=True)
    notes = Column(Text, nullable=True)
    price_target = Column(Float, nullable=True)
    
    def __repr__(self):
        return f"<WatchlistItem(ticker='{self.ticker}')>"

# Create tables
def init_db():
    Base.metadata.create_all(engine)

# Database operations for portfolio
def save_stock(ticker, quantity):
    """Save a stock to the database or update its quantity if it exists"""
    session = Session()
    try:
        # Check if the stock already exists
        stock = session.query(StockModel).filter_by(ticker=ticker).first()
        
        if stock:
            # Update quantity if the stock exists
            stock.quantity = quantity
            message = f"Updated {ticker} quantity to {quantity}"
        else:
            # Create a new stock entry
            stock = StockModel(ticker=ticker, quantity=quantity)
            session.add(stock)
            message = f"Added {ticker} to portfolio with quantity {quantity}"
            
        session.commit()
        return True, message
    except Exception as e:
        session.rollback()
        print(f"Error saving stock: {e}")
        return False, f"Error saving stock: {e}"
    finally:
        session.close()

def delete_stock(ticker):
    """Remove a stock from the database"""
    session = Session()
    try:
        stock = session.query(StockModel).filter_by(ticker=ticker).first()
        if stock:
            session.delete(stock)
            session.commit()
            return True, f"Removed {ticker} from portfolio"
        return False, f"{ticker} not found in portfolio"
    except Exception as e:
        session.rollback()
        print(f"Error deleting stock: {e}")
        return False, f"Error deleting stock: {e}"
    finally:
        session.close()

def get_all_stocks():
    """Retrieve all stocks from the database"""
    session = Session()
    try:
        stocks = session.query(StockModel).all()
        return {stock.ticker: stock.quantity for stock in stocks}
    except Exception as e:
        print(f"Error retrieving stocks: {e}")
        return {}
    finally:
        session.close()

# Database operations for watchlist
def add_to_watchlist(ticker, notes="", price_target=None):
    """Add a stock to the watchlist"""
    session = Session()
    try:
        # Check if the item already exists
        item = session.query(WatchlistModel).filter_by(ticker=ticker).first()
        
        if item:
            # Update existing item
            item.notes = notes
            item.price_target = price_target
            message = f"Updated {ticker} in watchlist"
        else:
            # Add new item
            item = WatchlistModel(ticker=ticker, notes=notes, price_target=price_target)
            session.add(item)
            message = f"Added {ticker} to watchlist"
        
        session.commit()
        return True, message
    except Exception as e:
        session.rollback()
        print(f"Error adding to watchlist: {e}")
        return False, f"Error adding to watchlist: {e}"
    finally:
        session.close()

def remove_from_watchlist(ticker):
    """Remove a stock from the watchlist"""
    session = Session()
    try:
        item = session.query(WatchlistModel).filter_by(ticker=ticker).first()
        
        if item:
            session.delete(item)
            session.commit()
            return True, f"Removed {ticker} from watchlist"
        else:
            return False, f"{ticker} not found in watchlist"
    except Exception as e:
        session.rollback()
        print(f"Error removing from watchlist: {e}")
        return False, f"Error removing from watchlist: {e}"
    finally:
        session.close()

def get_watchlist():
    """Retrieve all stocks from the watchlist"""
    session = Session()
    try:
        items = session.query(WatchlistModel).all()
        return {item.ticker: {"notes": item.notes, "price_target": item.price_target} for item in items}
    except Exception as e:
        print(f"Error retrieving watchlist: {e}")
        return {}
    finally:
        session.close()

def update_watchlist_item(ticker, notes=None, price_target=None):
    """Update notes or price target for a watchlist item"""
    session = Session()
    try:
        item = session.query(WatchlistModel).filter_by(ticker=ticker).first()
        
        if item:
            if notes is not None:
                item.notes = notes
            if price_target is not None:
                item.price_target = price_target
                
            session.commit()
            return True, f"Updated information for {ticker}"
        else:
            return False, f"{ticker} not found in watchlist"
    except Exception as e:
        session.rollback()
        print(f"Error updating watchlist item: {e}")
        return False, f"Error updating watchlist item: {e}"
    finally:
        session.close()

# Initialize the database
init_db()