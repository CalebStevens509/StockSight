import requests
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import os
import time

# Alpha Vantage API configuration
ALPHA_VANTAGE_API_KEY = os.environ.get('ALPHA_VANTAGE_API_KEY')
BASE_URL = 'https://www.alphavantage.co/query'

def get_stock_data(ticker, period='1y'):
    """
    Fetches historical stock data from Alpha Vantage API
    
    Args:
        ticker (str): Stock ticker symbol
        period (str): Time period - converting from yfinance format to Alpha Vantage
    
    Returns:
        DataFrame: Stock data with OHLCV columns
    """
    if not ALPHA_VANTAGE_API_KEY:
        print("Alpha Vantage API key not found")
        return None
        
    # Convert period to Alpha Vantage format
    if period in ['1d', '5d']:
        function = 'TIME_SERIES_INTRADAY'
        interval = '60min'  # hourly data for recent periods
    else:
        function = 'TIME_SERIES_DAILY'
        interval = None
    
    params = {
        'function': function,
        'symbol': ticker,
        'apikey': ALPHA_VANTAGE_API_KEY,
        'outputsize': 'full'  # Get full historical data
    }
    
    if interval:
        params['interval'] = interval
    
    try:
        response = requests.get(BASE_URL, params=params, timeout=30)
        data = response.json()
        
        # Check for API errors
        if 'Error Message' in data:
            print(f"Alpha Vantage API Error for {ticker}: {data['Error Message']}")
            return None
            
        if 'Note' in data:
            print(f"Alpha Vantage API Limit for {ticker}: {data['Note']}")
            return None
        
        # Parse the time series data
        if function == 'TIME_SERIES_INTRADAY':
            time_series_key = f'Time Series ({interval})'
        else:
            time_series_key = 'Time Series (Daily)'
            
        if time_series_key not in data:
            print(f"No time series data found for {ticker}")
            return None
            
        time_series = data[time_series_key]
        
        # Convert to DataFrame
        df_data = []
        for date_str, values in time_series.items():
            df_data.append({
                'Date': pd.to_datetime(date_str),
                'Open': float(values['1. open']),
                'High': float(values['2. high']),
                'Low': float(values['3. low']),
                'Close': float(values['4. close']),
                'Volume': int(values['5. volume'])
            })
        
        df = pd.DataFrame(df_data)
        df.set_index('Date', inplace=True)
        df.sort_index(inplace=True)
        
        # Filter by period if needed
        df = filter_by_period(df, period)
        
        if df.empty:
            print(f"No data available for {ticker} after filtering")
            return None
        
        # Calculate additional metrics
        df['Daily_Return'] = df['Close'].pct_change()
        df['Cumulative_Return'] = (1 + df['Daily_Return']).cumprod() - 1
        
        return df
        
    except Exception as e:
        print(f"Error fetching data for {ticker}: {e}")
        return None

def filter_by_period(df, period):
    """Filter DataFrame by the specified period"""
    if df.empty:
        return df
        
    end_date = df.index.max()
    
    period_map = {
        '1d': timedelta(days=1),
        '5d': timedelta(days=5),
        '1mo': timedelta(days=30),
        '3mo': timedelta(days=90),
        '6mo': timedelta(days=180),
        '1y': timedelta(days=365),
        '2y': timedelta(days=730),
        '5y': timedelta(days=1825),
    }
    
    if period in period_map:
        start_date = end_date - period_map[period]
        return df[df.index >= start_date]
    
    return df  # Return all data if period not recognized

def get_stock_info(ticker):
    """
    Get basic stock information from Alpha Vantage
    
    Args:
        ticker (str): Stock ticker symbol
        
    Returns:
        dict: Basic stock information
    """
    if not ALPHA_VANTAGE_API_KEY:
        return None
        
    params = {
        'function': 'OVERVIEW',
        'symbol': ticker,
        'apikey': ALPHA_VANTAGE_API_KEY
    }
    
    try:
        response = requests.get(BASE_URL, params=params, timeout=30)
        data = response.json()
        
        if 'Symbol' not in data:
            return None
            
        return {
            'symbol': data.get('Symbol', ticker),
            'name': data.get('Name', ticker),
            'sector': data.get('Sector', 'Unknown'),
            'industry': data.get('Industry', 'Unknown'),
            'market_cap': data.get('MarketCapitalization', 'N/A'),
            'pe_ratio': data.get('PERatio', 'N/A'),
            'dividend_yield': data.get('DividendYield', 'N/A'),
            'description': data.get('Description', '')
        }
        
    except Exception as e:
        print(f"Error fetching info for {ticker}: {e}")
        return None

def validate_ticker(ticker):
    """
    Validate if a ticker symbol exists using Alpha Vantage
    
    Args:
        ticker (str): Stock ticker symbol
        
    Returns:
        bool: True if ticker is valid
    """
    info = get_stock_info(ticker)
    return info is not None

def get_current_price(ticker):
    """
    Get the current/latest price for a ticker
    
    Args:
        ticker (str): Stock ticker symbol
        
    Returns:
        float: Current price or None if unavailable
    """
    if not ALPHA_VANTAGE_API_KEY:
        return None
        
    params = {
        'function': 'GLOBAL_QUOTE',
        'symbol': ticker,
        'apikey': ALPHA_VANTAGE_API_KEY
    }
    
    try:
        response = requests.get(BASE_URL, params=params, timeout=30)
        data = response.json()
        
        if 'Global Quote' in data and '05. price' in data['Global Quote']:
            return float(data['Global Quote']['05. price'])
            
        return None
        
    except Exception as e:
        print(f"Error fetching current price for {ticker}: {e}")
        return None

def calculate_metrics(data):
    """
    Calculate performance metrics for stock data
    
    Args:
        data (DataFrame): Stock data with OHLCV columns
        
    Returns:
        dict: Performance metrics
    """
    if data is None or data.empty:
        return None
        
    try:
        latest_price = data['Close'].iloc[-1]
        
        # Calculate returns for different periods
        returns = {}
        
        if len(data) >= 2:
            returns['1d'] = (data['Close'].iloc[-1] / data['Close'].iloc[-2] - 1) * 100
            
        if len(data) >= 5:
            returns['5d'] = (data['Close'].iloc[-1] / data['Close'].iloc[-5] - 1) * 100
            
        if len(data) >= 21:
            returns['1mo'] = (data['Close'].iloc[-1] / data['Close'].iloc[-21] - 1) * 100
            
        if len(data) >= 252:
            returns['1y'] = (data['Close'].iloc[-1] / data['Close'].iloc[-252] - 1) * 100
        
        # Calculate volatility
        volatility = data['Daily_Return'].std() * np.sqrt(252) * 100  # Annualized percentage
        
        # Calculate moving averages
        ma_20 = data['Close'].rolling(window=20).mean().iloc[-1] if len(data) >= 20 else None
        ma_50 = data['Close'].rolling(window=50).mean().iloc[-1] if len(data) >= 50 else None
        
        return {
            'current_price': latest_price,
            'returns': returns,
            'volatility': volatility,
            'ma_20': ma_20,
            'ma_50': ma_50,
            'volume': data['Volume'].iloc[-1] if 'Volume' in data.columns else None
        }
        
    except Exception as e:
        print(f"Error calculating metrics: {e}")
        return None