import pandas as pd
import numpy as np
from datetime import datetime, timedelta

def identify_trend(data, window=14):
    """
    Identify the current market trend (bullish, bearish, or sideways)
    based on moving averages and price action.
    
    Args:
        data: DataFrame with stock price data
        window: Period for moving averages
    
    Returns:
        Dictionary with trend information and confidence level
    """
    if data is None or len(data) < window * 2:
        return None
    
    # Calculate short and long-term moving averages
    data['SMA_short'] = data['Close'].rolling(window=window).mean()
    data['SMA_long'] = data['Close'].rolling(window=window*2).mean()
    
    # Calculate daily returns
    data['Daily_Return'] = data['Close'].pct_change()
    
    # Get recent data
    recent_data = data.iloc[-window:].copy()
    
    # Check if price is trending up, down, or sideways
    current_price = recent_data['Close'].iloc[-1]
    short_ma = recent_data['SMA_short'].iloc[-1]
    long_ma = recent_data['SMA_long'].iloc[-1]
    
    # Calculate price slope (rate of change)
    price_slope = (recent_data['Close'].iloc[-1] / recent_data['Close'].iloc[0] - 1) / window
    
    # Determine trend
    if short_ma > long_ma and price_slope > 0:
        trend = "bullish"
        strength = min(1.0, abs(price_slope) * 100)  # Scale factor to get a 0-1 score
    elif short_ma < long_ma and price_slope < 0:
        trend = "bearish"
        strength = min(1.0, abs(price_slope) * 100)
    else:
        trend = "sideways"
        strength = min(1.0, (1 - abs(price_slope) * 100))
    
    # Recent volatility - handle NaN values in returns
    try:
        volatility = recent_data['Daily_Return'].dropna().std() * np.sqrt(252)  # Annualized
    except:
        volatility = 0.0  # Default value if calculation fails
    
    # Check if volume is confirming the trend
    if 'Volume' in recent_data.columns:
        avg_volume = recent_data['Volume'].mean()
        latest_volume = recent_data['Volume'].iloc[-1]
        volume_increasing = latest_volume > avg_volume
    else:
        volume_increasing = None
    
    # Get the last window values for the moving averages for charting
    short_ma_values = data['SMA_short'].iloc[-window:].values
    long_ma_values = data['SMA_long'].iloc[-window:].values
    
    return {
        'trend': trend,
        'strength': strength,
        'volatility': volatility,
        'volume_confirming': volume_increasing,
        'current_price': current_price,
        'short_ma': short_ma,
        'long_ma': long_ma,
        'short_ma_values': short_ma_values,
        'long_ma_values': long_ma_values,
        'window': window
    }

def identify_support_resistance(data, window=20):
    """
    Identify potential support and resistance levels
    
    Args:
        data: DataFrame with stock price data
        window: Lookback period for identification
        
    Returns:
        Dictionary with support and resistance levels
    """
    if data is None or len(data) < window:
        return None
    
    recent_data = data.iloc[-window:]
    
    # Find potential support (recent lows)
    lows = recent_data['Low'].nsmallest(3).values
    
    # Find potential resistance (recent highs)
    highs = recent_data['High'].nlargest(3).values
    
    current_price = recent_data['Close'].iloc[-1]
    
    # Return closest support and resistance levels to current price
    support_levels = [float(price) for price in lows if price < current_price]
    resistance_levels = [float(price) for price in highs if price > current_price]
    
    return {
        'current_price': current_price,
        'support_levels': support_levels if support_levels else [float(recent_data['Low'].min())],
        'resistance_levels': resistance_levels if resistance_levels else [float(recent_data['High'].max())]
    }

def identify_candlestick_patterns(data):
    """
    Identify common candlestick patterns in the recent data
    
    Args:
        data: DataFrame with stock price data
        
    Returns:
        List of identified candlestick patterns with their signals
    """
    if data is None or len(data) < 5:
        return None
    
    patterns = []
    
    # Get the most recent candles
    recent_data = data.iloc[-5:].copy()
    
    # Basic candle properties
    recent_data['body_size'] = abs(recent_data['Close'] - recent_data['Open'])
    recent_data['upper_shadow'] = recent_data.apply(
        lambda x: x['High'] - max(x['Open'], x['Close']), axis=1
    )
    recent_data['lower_shadow'] = recent_data.apply(
        lambda x: min(x['Open'], x['Close']) - x['Low'], axis=1
    )
    recent_data['is_bullish'] = recent_data['Close'] > recent_data['Open']
    
    # Look at the most recent candle (today)
    last_candle = recent_data.iloc[-1]
    second_last_candle = recent_data.iloc[-2] if len(recent_data) >= 2 else None
    third_last_candle = recent_data.iloc[-3] if len(recent_data) >= 3 else None
    
    avg_body_size = recent_data['body_size'].mean()
    
    # Doji (small body, shadows on both sides)
    if last_candle['body_size'] < 0.3 * avg_body_size and last_candle['upper_shadow'] > 0 and last_candle['lower_shadow'] > 0:
        patterns.append({
            'name': 'Doji',
            'signal': 'indecision', 
            'description': 'A Doji indicates market indecision. After an uptrend, it may signal reversal. After a downtrend, it may signal potential bottom.'
        })
    
    # Hammer (bullish reversal pattern)
    if (last_candle['lower_shadow'] > 2 * last_candle['body_size'] and 
        last_candle['upper_shadow'] < 0.2 * last_candle['body_size']):
        patterns.append({
            'name': 'Hammer',
            'signal': 'bullish reversal',
            'description': 'A hammer forms during a downtrend and indicates potential reversal to the upside. The long lower shadow suggests buyers stepped in.'
        })
    
    # Shooting Star (bearish reversal pattern)
    if (last_candle['upper_shadow'] > 2 * last_candle['body_size'] and 
        last_candle['lower_shadow'] < 0.2 * last_candle['body_size']):
        patterns.append({
            'name': 'Shooting Star',
            'signal': 'bearish reversal',
            'description': 'A shooting star appears after an uptrend and signals potential reversal. The long upper shadow indicates rejected higher prices.'
        })
    
    # Engulfing patterns (need at least 2 candles)
    if second_last_candle is not None:
        # Bullish Engulfing
        if (not second_last_candle['is_bullish'] and  # Previous candle is bearish
            last_candle['is_bullish'] and  # Current candle is bullish
            last_candle['Open'] < second_last_candle['Close'] and
            last_candle['Close'] > second_last_candle['Open']):
            patterns.append({
                'name': 'Bullish Engulfing',
                'signal': 'bullish reversal',
                'description': 'A bullish engulfing pattern forms after a downtrend when a bullish candle completely engulfs the previous bearish candle, indicating strong buying pressure.'
            })
        
        # Bearish Engulfing
        if (second_last_candle['is_bullish'] and  # Previous candle is bullish
            not last_candle['is_bullish'] and  # Current candle is bearish
            last_candle['Open'] > second_last_candle['Close'] and
            last_candle['Close'] < second_last_candle['Open']):
            patterns.append({
                'name': 'Bearish Engulfing',
                'signal': 'bearish reversal',
                'description': 'A bearish engulfing pattern forms after an uptrend when a bearish candle completely engulfs the previous bullish candle, indicating strong selling pressure.'
            })
    
    # Morning Star (bullish reversal, needs 3 candles)
    if third_last_candle is not None and second_last_candle is not None:
        if (not third_last_candle['is_bullish'] and  # First candle is bearish with large body
            third_last_candle['body_size'] > avg_body_size and
            second_last_candle['body_size'] < 0.5 * avg_body_size and  # Middle candle is small
            last_candle['is_bullish'] and  # Last candle is bullish
            last_candle['body_size'] > avg_body_size):
            patterns.append({
                'name': 'Morning Star',
                'signal': 'bullish reversal',
                'description': 'A morning star is a bottom reversal pattern. It begins with a bearish candle, followed by a small candle, and completed with a strong bullish candle, showing a shift from selling to buying.'
            })
    
    # Evening Star (bearish reversal, needs 3 candles)
    if third_last_candle is not None and second_last_candle is not None:
        if (third_last_candle['is_bullish'] and  # First candle is bullish with large body
            third_last_candle['body_size'] > avg_body_size and
            second_last_candle['body_size'] < 0.5 * avg_body_size and  # Middle candle is small
            not last_candle['is_bullish'] and  # Last candle is bearish
            last_candle['body_size'] > avg_body_size):
            patterns.append({
                'name': 'Evening Star',
                'signal': 'bearish reversal',
                'description': 'An evening star is a top reversal pattern. It begins with a bullish candle, followed by a small candle, and completed with a strong bearish candle, showing a shift from buying to selling.'
            })
    
    return patterns

def generate_stock_recommendation(ticker, data, quantity=1):
    """
    Generate recommendations for a stock based on technical indicators
    
    Args:
        ticker: Stock ticker symbol
        data: DataFrame with stock price data
        quantity: Current quantity owned
        
    Returns:
        Dictionary with recommendation information
    """
    if data is None or len(data) < 30:
        return {
            'ticker': ticker,
            'quantity': quantity,
            'recommendation': 'hold',
            'confidence': 0,
            'reason': 'Insufficient data for analysis',
            'advice': 'Wait for more market data to become available before making investment decisions.'
        }
    
    # Get trend analysis
    trend_data = identify_trend(data)
    if trend_data is None:
        return {
            'ticker': ticker,
            'quantity': quantity,
            'recommendation': 'hold',
            'confidence': 0,
            'reason': 'Unable to analyze trend',
            'advice': 'Wait for clearer market signals before making investment decisions.'
        }
    
    # Get support/resistance levels
    levels = identify_support_resistance(data)
    if levels is None:
        levels = {'support_levels': [], 'resistance_levels': []}
    
    # Get candlestick patterns
    patterns = identify_candlestick_patterns(data)
    
    # Default values
    recommendation = 'hold'
    confidence = 0.5
    reason = []
    advice = []
    
    # Make recommendation based on trend
    if trend_data['trend'] == 'bullish':
        if quantity == 0:
            recommendation = 'buy'
            confidence = trend_data['strength']
            reason.append(f"Bullish trend detected with {trend_data['strength']:.1%} strength")
            advice.append(f"Consider buying as price is trending upward")
        else:
            recommendation = 'hold'
            confidence = trend_data['strength']
            reason.append(f"Bullish trend continues with {trend_data['strength']:.1%} strength")
            advice.append(f"Continue holding as uptrend remains intact")
            
        if levels and levels['resistance_levels']:
            next_resistance = min(levels['resistance_levels'])
            potential_gain = (next_resistance / trend_data['current_price'] - 1) * 100
            advice.append(f"Next resistance at ${next_resistance:.2f} ({potential_gain:.1f}% potential gain)")
    
    elif trend_data['trend'] == 'bearish':
        if quantity > 0:
            if trend_data['strength'] > 0.7:  # Strong bearish trend
                recommendation = 'sell'
                confidence = trend_data['strength']
                reason.append(f"Strong bearish trend detected with {trend_data['strength']:.1%} strength")
                advice.append(f"Consider selling to prevent further losses")
            else:
                recommendation = 'hold'
                confidence = 1 - trend_data['strength']
                reason.append(f"Bearish trend detected with {trend_data['strength']:.1%} strength")
                advice.append(f"Monitor closely as price is trending downward")
        else:
            recommendation = 'avoid'
            confidence = trend_data['strength']
            reason.append(f"Bearish trend detected with {trend_data['strength']:.1%} strength")
            advice.append(f"Avoid buying until trend reverses")
            
        if levels and levels['support_levels']:
            next_support = max(levels['support_levels'])
            potential_loss = (1 - next_support / trend_data['current_price']) * 100
            advice.append(f"Next support at ${next_support:.2f} ({potential_loss:.1f}% potential drop)")
    
    else:  # Sideways trend
        recommendation = 'hold'
        confidence = trend_data['strength']
        reason.append(f"Sideways trend detected with {trend_data['volatility']:.1%} volatility")
        advice.append(f"Hold position as market consolidates")
        
        if levels:
            if levels['resistance_levels']:
                next_resistance = min(levels['resistance_levels'])
                advice.append(f"Consider taking profits near resistance at ${next_resistance:.2f}")
            if levels['support_levels']:
                next_support = max(levels['support_levels'])
                advice.append(f"Consider adding to position near support at ${next_support:.2f}")
    
    # Adjust recommendation based on candlestick patterns
    if patterns:
        pattern_signals = [p['signal'] for p in patterns]
        pattern_names = [p['name'] for p in patterns]
        
        # Strong reversal signals can flip the recommendation
        if 'bullish reversal' in pattern_signals and recommendation in ['hold', 'sell', 'avoid']:
            if quantity == 0:
                recommendation = 'buy'
                confidence = 0.6  # Moderate confidence for pattern-based decisions
            else:
                recommendation = 'hold'
                confidence = 0.7
            bullish_patterns = [p['name'] for p in patterns if p['signal'] == 'bullish reversal']
            reason.append(f"Bullish reversal pattern(s) detected: {', '.join(bullish_patterns)}")
            advice.append(f"Consider buying as reversal patterns suggest upward movement")
            
        elif 'bearish reversal' in pattern_signals and recommendation in ['hold', 'buy']:
            if quantity > 0:
                recommendation = 'sell'
                confidence = 0.6
            else:
                recommendation = 'avoid'
                confidence = 0.7
            bearish_patterns = [p['name'] for p in patterns if p['signal'] == 'bearish reversal']
            reason.append(f"Bearish reversal pattern(s) detected: {', '.join(bearish_patterns)}")
            advice.append(f"Consider selling as reversal patterns suggest downward movement")
        
        # Add pattern information to reason
        if pattern_names and pattern_names not in reason:
            reason.append(f"Detected patterns: {', '.join(pattern_names)}")
    
    # Add volume confirmation to reason if available
    if trend_data.get('volume_confirming') is not None:
        if trend_data['volume_confirming']:
            reason.append(f"Increasing volume confirms the {trend_data['trend']} trend")
            # Increase confidence slightly for volume confirmation
            confidence = min(1.0, confidence + 0.1)
        else:
            reason.append(f"Decreasing volume suggests weakening {trend_data['trend']} trend")
            # Decrease confidence slightly for lack of volume confirmation
            confidence = max(0.0, confidence - 0.1)
    
    # Generate final advice message
    final_advice = '. '.join(advice)
    
    # Return the comprehensive recommendation
    # Ensure trend_data has a trend value, default to 'neutral' if not available
    trend_value = trend_data['trend'] if trend_data and 'trend' in trend_data else 'neutral'
    
    # Create a summary of key points for quick reference
    summary_points = []
    summary_points.append(f"• Current trend is {trend_value} with {confidence:.0%} confidence")
    
    if reason:
        # Add the first reason to the summary points
        summary_points.append(f"• {reason[0]}")
    
    # Add price levels if available
    if levels:
        if 'resistance_levels' in levels and levels['resistance_levels']:
            summary_points.append(f"• Next resistance at ${min(levels['resistance_levels']):.2f}")
        if 'support_levels' in levels and levels['support_levels']:
            summary_points.append(f"• Next support at ${max(levels['support_levels']):.2f}")
    
    # Add a pattern summary if available
    if patterns:
        pattern_names = [p['name'] for p in patterns]
        summary_points.append(f"• Patterns detected: {', '.join(pattern_names[:2])}")
    
    # Add enhanced investment metrics
    metrics = {}
    risk_factors = []
    targets = {}
    
    # Calculate momentum score (0-100) based on recent price action
    if len(data) >= 60:
        # Use 60-day rate of change as basis for momentum
        momentum = ((data['Close'].iloc[-1] / data['Close'].iloc[-60]) - 1) * 100
        # Normalize between 0-100
        normalized_momentum = max(0, min(100, 50 + momentum * 2.5))
        metrics['momentum'] = normalized_momentum
        summary_points.append(f"• Momentum score: {normalized_momentum:.0f}/100")
    
    # Calculate risk score (0-100) based on volatility
    if 'volatility' in trend_data:
        # Convert annual volatility to risk score
        annual_vol = trend_data['volatility']
        risk_score = min(100, annual_vol * 250)  # Cap at 100
        metrics['risk'] = risk_score
        
        # Add risk factors based on volatility
        if annual_vol > 0.3:
            risk_factors.append(f"High volatility ({annual_vol:.1%} annual)")
        elif annual_vol > 0.2:
            risk_factors.append(f"Moderate volatility ({annual_vol:.1%} annual)")
    
    # Add price targets using support/resistance levels
    if levels:
        current_price = data['Close'].iloc[-1]
        targets['current'] = current_price
        
        if 'resistance_levels' in levels and levels['resistance_levels']:
            targets['resistance'] = min(levels['resistance_levels'])
        
        if 'support_levels' in levels and levels['support_levels']:
            targets['support'] = max(levels['support_levels'])
        
        # Calculate potential return for buy recommendations
        if 'resistance_levels' in levels and levels['resistance_levels'] and recommendation == 'buy':
            next_resistance = min(levels['resistance_levels'])
            potential_upside = (next_resistance - current_price) / current_price
            metrics['potential_return'] = potential_upside
    
    # Add watch levels for hold recommendations
    watch_levels = {}
    if recommendation == 'hold' and levels:
        current_price = data['Close'].iloc[-1]
        watch_levels['current'] = current_price
        
        if 'resistance_levels' in levels and levels['resistance_levels']:
            # Suggest selling if price moves above resistance
            watch_levels['sell_above'] = min(levels['resistance_levels']) * 1.02  # 2% above resistance
        
        if 'support_levels' in levels and levels['support_levels']:
            # Suggest buying if price drops to support
            watch_levels['buy_below'] = max(levels['support_levels']) * 0.98  # 2% below support
    
    # Create exit strategy
    exit_strategy = None
    if recommendation == 'buy' and 'resistance_levels' in levels and levels['resistance_levels']:
        target_price = min(levels['resistance_levels'])
        current_price = data['Close'].iloc[-1]
        exit_pct = (target_price - current_price) / current_price
        exit_strategy = f"Consider taking profits when the price reaches ${target_price:.2f} (approximately {exit_pct:.1%} gain). Set a trailing stop loss at 7-10% below your purchase price to protect against unexpected downside."
    elif recommendation == 'sell':
        exit_strategy = f"If selling, consider a phased approach by reducing your position in increments rather than all at once. This helps mitigate timing risk in case the market reverses."
    
    # For hold recommendations, add position strength indicator
    position_strength = None
    if recommendation == 'hold':
        # Calculate position strength based on multiple factors
        trend_score = 0.5  # Neutral baseline
        if trend_value == 'bullish':
            trend_score = 0.5 + (confidence * 0.5)  # 0.5-1.0 range
        elif trend_value == 'bearish':
            trend_score = 0.5 - (confidence * 0.5)  # 0.0-0.5 range
        
        # Pattern score based on detected patterns
        pattern_score = 0.5  # Neutral baseline
        if patterns:
            bullish_count = sum(1 for p in patterns if 'bullish' in p.get('signal', ''))
            bearish_count = sum(1 for p in patterns if 'bearish' in p.get('signal', ''))
            if bullish_count > bearish_count:
                pattern_score = 0.7
            elif bearish_count > bullish_count:
                pattern_score = 0.3
        
        # Combine into position strength (0-100 scale)
        position_strength = (trend_score * 0.7 + pattern_score * 0.3) * 100
        position_strength = min(100, max(0, position_strength))
    
    return {
        'ticker': ticker,
        'quantity': quantity,
        'recommendation': recommendation,
        'confidence': confidence,
        'reason': ' | '.join(reason),
        'advice': final_advice,
        'summary': '\n'.join(summary_points),  # Add the summary points as a formatted string
        'trend': trend_value,
        'patterns': patterns if patterns else [],
        'metrics': metrics,
        'risk_factors': risk_factors,
        'targets': targets,
        'exit_strategy': exit_strategy,
        'watch_levels': watch_levels if watch_levels else None,
        'position_strength': position_strength
    }

def get_recommendations_for_portfolio(portfolio_data):
    """
    Generate recommendations for all stocks in a portfolio
    
    Args:
        portfolio_data: Dictionary mapping ticker symbols to data DataFrames
        
    Returns:
        List of recommendation dictionaries
    """
    recommendations = []
    
    for ticker, data in portfolio_data.items():
        quantity = data.get('quantity', 1)  # Default to 1 if quantity not provided
        price_data = data.get('price_data')
        
        recommendation = generate_stock_recommendation(ticker, price_data, quantity)
        recommendations.append(recommendation)
    
    return recommendations